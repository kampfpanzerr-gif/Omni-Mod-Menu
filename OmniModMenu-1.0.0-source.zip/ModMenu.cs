using System;
using System.Collections.Generic;
using System.Linq;
using BepInEx;
using BepInEx.Configuration;
using RoR2;
using UnityEngine;

namespace RoR2ModMenu
{
    class Entry
    {
        public string name = "";
        public string sub = "";
        public string search = "";
        public Color color = Color.white;
        public Texture tex;
        public Rect uv = new Rect(0, 0, 1, 1);
        public int group;
        public object data;
        public GameObject prefab;
        public string extra = ""; // дополнительная подпись у кнопки (например, длительность песни)
        public bool header;      // строка-заголовок группы
        public string lockWhy;   // не null - выбор недоступен (например, DLC)
    }

    class ScanItem
    {
        public GameObject go;
        public int kind; // 0 - интерактив, 1 - выпавший предмет
        public string name = "";
        public Color color = Color.white;
        public string cost = "";
        public string content = "";
        public int group = -1; // редкость содержимого (как у TierGroup, 7 - снаряжение), -1 - нет предмета
        public Color contentColor = Color.white;
        public Texture contentTex;
        public Rect contentUv = new Rect(0, 0, 1, 1);
        public Vector3 pos;
        public float dist;
    }

    [BepInPlugin("user.omni.modmenu", "Omni Mod Menu", "1.0.0")]
    public partial class ModMenu : BaseUnityPlugin
    {
        ConfigEntry<string> cfgLang;
        ConfigEntry<float> cfgScale;
        ConfigEntry<float> cfgOpacity;
        ConfigEntry<int> cfgTheme, cfgBgTheme, cfgHudMode, cfgHudCorner;
        ConfigEntry<bool> cfgHud;
        ConfigEntry<string> cfgAccentHex, cfgBgHex, cfgGradAHex, cfgGradBHex;

        // ---------- состояние читов ----------
        bool god, infJumps, fly, noclip, freeInteract, noEnemies;
        float flySpeed = 20f;
        float timeScale = 1f;
        bool flyWasActive, gravityOff;
        bool noclipApplied;
        int savedLayers;

        // множители: 0 игрок, 1 союзники, 2 враги, 3 боссы
        float[] hpMul = { 1, 1, 1, 1 };
        float[] dmgMul = { 1, 1, 1, 1 };
        float speedMul = 1f, atkSpeedMul = 1f, jumpMul = 1f;
        readonly Dictionary<int, float[]> origStats = new Dictionary<int, float[]>();

        // ---------- каталоги ----------
        List<Entry> items, equips, survivors, allBodies, enemies, drones, scenes;
        bool catalogsBuilt;

        // ---------- сканер ----------
        readonly List<ScanItem> scan = new List<ScanItem>();
        float nextScan;
        bool espOn, espInteract = true, espPickups = true, espContents = true;
        float espRange = 150f;
        string espFilter = "";

        string status = "";
        float statusUntil;

        void Awake()
        {
            cfgLang = Config.Bind("General", "Language", "auto", "auto = follow the game's language until you pick one in Settings; otherwise a language code (en, uk, ru, de, es, fr, it, pt, tr, ja, ko, zh)");
            cfgScale = Config.Bind("Interface", "UiScale", 1f, "UI scale");
            cfgOpacity = Config.Bind("Interface", "UiOpacity", 0.96f, "Window background opacity");
            cfgTheme = Config.Bind("Interface", "Theme", 0, "Accent color theme index");
            cfgBgTheme = Config.Bind("Interface", "Background", 0, "Background theme index");
            cfgAccentHex = Config.Bind("Interface", "CustomAccent", "38A0F2", "Custom accent color (hex)");
            cfgBgHex = Config.Bind("Interface", "CustomBackground", "13161E", "Custom background color (hex)");
            cfgGradAHex = Config.Bind("Interface", "CustomGradientA", "FF8A3D", "Custom gradient color A (hex)");
            cfgGradBHex = Config.Bind("Interface", "CustomGradientB", "E83E8C", "Custom gradient color B (hex)");
            cfgHud = Config.Bind("Hud", "Enabled", false, "Show the list of active features in a screen corner");
            cfgHudMode = Config.Bind("Hud", "Mode", 1, "0 = only while the menu is open, 1 = always");
            cfgHudCorner = Config.Bind("Hud", "Corner", 0, "0 = top-left, 1 = top-right, 2 = bottom-left, 3 = bottom-right");
            cfgFps = Config.Bind("Fps", "Enabled", false, "Show an FPS counter (also while the menu is hidden)");
            cfgFpsMode = Config.Bind("Fps", "Mode", 0, "0 = simple, 1 = detailed");
            cfgFpsColorMode = Config.Bind("Fps", "ColorMode", 0, "0 = green, 1 = menu accent color, 2 = custom");
            cfgFpsHex = Config.Bind("Fps", "CustomColor", "33FF59", "Custom FPS counter color (hex)");
            cfgFpsOutline = Config.Bind("Fps", "Outline", false, "Draw an outline around the FPS counter text");
            cfgFpsSize = Config.Bind("Fps", "Size", 18, "FPS counter font size");
            cfgFpsPos = Config.Bind("Fps", "Position", 0, "0 TL, 1 TC, 2 TR, 3 BL, 4 BC, 5 BR");
            cfgPing = Config.Bind("Ping", "Enabled", false, "Show a ping counter (also while the menu is hidden)");
            cfgPingMode = Config.Bind("Ping", "Mode", 0, "0 = simple, 1 = detailed");
            cfgPingPos = Config.Bind("Ping", "Position", 2, "0 TL, 1 TC, 2 TR, 3 BL, 4 BC, 5 BR");
            InitBinds();
            InitHarmony();
            CharacterBody.onBodyStartGlobal += OnBodyStart;
            MusicController.pickTrackHook += PickTrack;
            Logger.LogInfo("Omni Mod Menu loaded. Press " + KeyText(binds[0].k1.Value) + " in game.");
        }

        void OnDestroy()
        {
            CharacterBody.onBodyStartGlobal -= OnBodyStart;
            MusicController.pickTrackHook -= PickTrack;
            if (hudApplied) { hideGameHud = false; ApplyGameHud(); }
            if (inputBlocked) SetInputBlocked(false);
            ShutdownHarmony();
        }

        // ---------- доступ к игроку ----------
        PlayerCharacterMasterController Pcmc
        {
            get { return PlayerCharacterMasterController.instances.Count > 0 ? PlayerCharacterMasterController.instances[0] : null; }
        }

        CharacterMaster Master
        {
            get { var p = Pcmc; return p != null ? p.master : null; }
        }

        CharacterBody Body
        {
            get { var m = Master; return m != null ? m.GetBody() : null; }
        }

        void Say(string s)
        {
            status = s;
            statusUntil = Time.unscaledTime + 4f;
        }

        void Cmd(string cmd)
        {
            var lu = LocalUserManager.GetFirstLocalUser();
            RoR2.Console.instance.SubmitCmd(lu != null ? lu.currentNetworkUser : null, cmd, false);
        }

        // ---------- главный цикл ----------
        readonly HashSet<RoR2.UI.MPEventSystem> cursorHeld = new HashSet<RoR2.UI.MPEventSystem>();

        void Update()
        {
            UpdateLanguage();
            ProcessHotkeys();
            UpdateCursor();
            UpdateInputBlock();
            ApplyGameHud();
            SampleFps();
            SamplePing();
            PlayersTick();

            if ((espOn || freeInteract || (open && (tab == TTele || tab == TScan))) && Time.unscaledTime >= nextScan)
            {
                nextScan = Time.unscaledTime + 0.5f;
                RefreshScan();
            }

            var body = Body;
            if (body == null) return;

            var hc = body.healthComponent;
            if (hc != null && (god || hc.godMode)) hc.godMode = god;

            var motor = body.characterMotor;
            if (motor == null) return;

            if (infJumps && !motor.isGrounded && Input.GetKeyDown(KeyCode.Space))
                motor.jumpCount = 0;

            TickCooldowns(body);
            AimbotTick(body);

            EnforceNoclip();
            bool flying = fly || noclip;
            if (flying && body.inputBank != null)
            {
                float boost = Input.GetKey(KeyCode.LeftShift) ? 2f : 1f;
                Vector3 mv = body.inputBank.moveVector;
                Vector3 aim = body.inputBank.aimDirection;
                float vert = (Input.GetKey(KeyCode.Space) ? 1f : 0f) - (Input.GetKey(KeyCode.LeftControl) ? 1f : 0f);
                Vector3 v = mv * flySpeed * boost;
                v.y = (vert + aim.y * mv.magnitude) * flySpeed * boost;
                // способности могут сбросить параметры гравитации, поэтому счётчик проверяем каждый кадр
                var gp = motor.gravityParameters;
                if (gp.channeledAntiGravityGranterCount < 1) { gp.channeledAntiGravityGranterCount = 1; motor.gravityParameters = gp; gravityOff = true; }
                motor.disableAirControlUntilCollision = false;
                motor.velocity = v;
                flyWasActive = true;
            }
            else if (flyWasActive)
            {
                if (gravityOff) { var gp2 = motor.gravityParameters; gp2.channeledAntiGravityGranterCount = 0; motor.gravityParameters = gp2; }
                gravityOff = false;
                flyWasActive = false;
            }
        }

        static void Refill(GenericSkill s)
        {
            if (s != null && s.stock < s.maxStock) s.stock = s.maxStock;
        }

        // Пока меню открыто, считаемся «открывателем курсора»: игра сама показывает мышь и не крутит камеру.
        void UpdateCursor()
        {
            if (open)
            {
                foreach (var es in RoR2.UI.MPEventSystem.readOnlyInstancesList)
                {
                    if (es == null || cursorHeld.Contains(es)) continue;
                    es.cursorOpenerCount++;
                    cursorHeld.Add(es);
                }
            }
            else if (cursorHeld.Count > 0)
            {
                foreach (var es in cursorHeld)
                    if (es != null && es.cursorOpenerCount > 0) es.cursorOpenerCount--;
                cursorHeld.Clear();
            }
        }

        // ---------- статы (HP / урон / скорость) ----------
        int Category(CharacterBody b)
        {
            if (b.isPlayerControlled) return 0;
            if (b.teamComponent != null && b.teamComponent.teamIndex == TeamIndex.Player) return 1;
            if (b.isChampion || b.isBoss) return 3;
            return 2;
        }

        void OnBodyStart(CharacterBody b)
        {
            if (b != null) ApplyTo(b, true);
        }

        void ApplyTo(CharacterBody b, bool heal)
        {
            int id = b.GetInstanceID();
            float[] o;
            if (!origStats.TryGetValue(id, out o))
            {
                o = new float[] { b.baseMaxHealth, b.baseDamage, b.baseMoveSpeed, b.baseAttackSpeed, b.baseJumpPower, b.baseArmor, b.baseCrit };
                origStats[id] = o;
            }
            int c = Category(b);
            float hp = o[0] * hpMul[c];
            float dmg = o[1] * dmgMul[c];
            float spd = o[2], atk = o[3], jmp = o[4], arm = o[5], crit = o[6];
            if (c == 0)
            {
                // ползунки вкладки «Игрок» относятся к локальному игроку, вкладки «Игроки» - к выбранному
                var master = b.master;
                if (master != null && master == Master) { spd *= speedMul; atk *= atkSpeedMul; jmp *= jumpMul; }
                if (master != null)
                {
                    var pm = ModsFor(master);
                    hp *= pm.hp; dmg *= pm.dmg; spd *= pm.spd; atk *= pm.atk; jmp *= pm.jump;
                    arm += pm.armor; crit += pm.critChance;
                }
            }

            bool hpChanged = !Mathf.Approximately(hp, b.baseMaxHealth);
            if (!hpChanged && Mathf.Approximately(dmg, b.baseDamage) && Mathf.Approximately(spd, b.baseMoveSpeed)
                && Mathf.Approximately(atk, b.baseAttackSpeed) && Mathf.Approximately(jmp, b.baseJumpPower)
                && Mathf.Approximately(arm, b.baseArmor) && Mathf.Approximately(crit, b.baseCrit)) return;

            b.baseMaxHealth = hp;
            b.baseDamage = dmg;
            b.baseMoveSpeed = spd;
            b.baseAttackSpeed = atk;
            b.baseJumpPower = jmp;
            b.baseArmor = arm;
            b.baseCrit = crit;
            b.RecalculateStats();
            if (heal && hpChanged && b.healthComponent != null)
                b.healthComponent.HealFraction(1f, default(ProcChainMask));
        }

        void ApplyAll()
        {
            var dead = origStats.Keys.ToList();
            foreach (var b in CharacterBody.readOnlyInstancesList)
            {
                if (b == null) continue;
                dead.Remove(b.GetInstanceID());
                ApplyTo(b, true);
            }
            foreach (var id in dead) origStats.Remove(id);
        }

        // ---------- действия ----------
        void GiveMoney(uint amount)
        {
            var m = Master;
            if (m == null) return;
            m.GiveMoney(amount);
            Say("+$" + amount);
        }

        void GiveLunar(uint amount)
        {
            var u = LocalUserManager.GetFirstLocalUser();
            if (u == null || u.userProfile == null) return;
            u.userProfile.coins += amount;
            Say("+" + amount + " " + T("lunar coins", "лунных монет", "місячних монет"));
        }

        void GiveLevels(int n)
        {
            if (TeamManager.instance == null) return;
            for (int i = 0; i < n; i++)
            {
                ulong need = TeamManager.instance.GetTeamNextLevelExperience(TeamIndex.Player)
                             - TeamManager.instance.GetTeamExperience(TeamIndex.Player);
                TeamManager.instance.GiveTeamExperience(TeamIndex.Player, need);
            }
            Say("+" + n + " " + T("levels", "ур.", "рів."));
        }

        void HealFull()
        {
            var b = Body;
            if (b != null && b.healthComponent != null)
                b.healthComponent.HealFraction(1f, default(ProcChainMask));
        }

        void GiveItem(Inventory inv, Entry e, int n)
        {
            var def = (ItemDef)e.data;
            if (inv == null) return;
            if (n > 0) inv.GiveItemPermanent(def.itemIndex, n);
            else
            {
                int have = inv.GetItemCountPermanent(def.itemIndex);
                int take = Math.Min(have, -n);
                if (take > 0) inv.RemoveItemPermanent(def.itemIndex, take);
            }
            Say((n > 0 ? "+" : "") + n + "  " + e.name);
        }

        void RemoveAllItems(Inventory inv)
        {
            if (inv == null || items == null) return;
            foreach (var e in items)
            {
                var def = (ItemDef)e.data;
                int have = inv.GetItemCountPermanent(def.itemIndex);
                if (have > 0) inv.RemoveItemPermanent(def.itemIndex, have);
            }
            Say(T("All items removed", "Все предметы удалены", "Усі предмети видалено"));
        }

        void SetEquipment(Inventory inv, EquipmentIndex idx, string name)
        {
            if (inv == null) return;
            inv.SetEquipmentIndex(idx);
            try
            {
                // если старый вызов не сработал (часть нового снаряжения), пробуем новый, с явным слотом
                if (idx != EquipmentIndex.None && inv.GetEquipment(0u).equipmentIndex != idx)
                {
                    var loc = EquipmentLocation.zero;
                    inv.SetEquipmentIndex(idx, ref loc);
                }
            }
            catch (Exception ex) { Logger.LogWarning("SetEquipment fallback: " + ex.Message); }
            Say(T("Equipment: ", "Снаряжение: ", "Спорядження: ") + name);
        }

        void SwitchCharacter(Entry e)
        {
            var m = Master;
            if (m == null || e.prefab == null) return;
            string why = LockReason(e.prefab, e.data as SurvivorDef);
            if (why != null)
            {
                Say(e.name + ": " + why);
                return;
            }
            m.TransformBody(e.prefab.name);
            Say(T("Character: ", "Персонаж: ", "Персонаж: ") + e.name);
        }

        void TeleportMe(Vector3 pos, string name)
        {
            var b = Body;
            if (b == null) return;
            TeleportHelper.TeleportBody(b, pos);
            Say(T("Teleported: ", "Телепорт: ", "Телепорт: ") + name);
        }

        void GoToStage(Entry e)
        {
            if (Run.instance == null)
            {
                Say(T("Start a run first", "Сначала начните забег", "Спочатку почніть забіг"));
                return;
            }
            Run.instance.AdvanceStage((SceneDef)e.data);
        }

        Vector3 AimPoint(CharacterBody b)
        {
            Vector3 o = b.inputBank != null ? b.inputBank.aimOrigin : b.corePosition;
            Vector3 d = b.inputBank != null ? b.inputBank.aimDirection : b.transform.forward;
            RaycastHit h;
            if (Physics.Raycast(o, d, out h, 200f, LayerIndex.world.mask))
                return h.point + Vector3.up * 1.5f;
            return o + d * 10f;
        }

        void Summon(GameObject masterPrefab, TeamIndex team, bool owned, int count, string name)
        {
            var body = Body;
            if (body == null || masterPrefab == null) return;
            Vector3 p = AimPoint(body);
            for (int i = 0; i < count; i++)
            {
                var ms = new MasterSummon();
                ms.masterPrefab = masterPrefab;
                ms.position = p + new Vector3(UnityEngine.Random.Range(-2f, 2f), 0f, UnityEngine.Random.Range(-2f, 2f));
                ms.rotation = Quaternion.identity;
                ms.teamIndexOverride = team;
                ms.ignoreTeamMemberLimit = true;
                if (owned) ms.summonerBodyObject = body.gameObject;
                ms.Perform();
            }
            Say(T("Spawned: ", "Создано: ", "Створено: ") + name + " x" + count);
        }

        void ChargeTeleporter()
        {
            if (TeleporterInteraction.instance != null && TeleporterInteraction.instance.holdoutZoneController != null)
            {
                TeleporterInteraction.instance.holdoutZoneController.FullyChargeHoldoutZone();
                Say(T("Teleporter charged", "Телепортер заряжен", "Телепорт заряджено"));
            }
            else Say(T("No teleporter on this stage", "На этой локации нет телепортера", "На цій локації немає телепорта"));
        }

        void OpenAllChests()
        {
            int n = 0;
            foreach (var pi in InstanceTracker.GetInstancesList<PurchaseInteraction>())
            {
                if (pi == null) continue;
                var cb = pi.GetComponent<ChestBehavior>();
                if (cb != null && !cb.isChestOpened) { cb.Open(); n++; }
            }
            Say(T("Chests opened: ", "Открыто сундуков: ", "Відкрито скринь: ") + n);
        }

        // ---------- сканер ----------
        Color PickupColor(PickupDef def)
        {
            return def.baseColor;
        }

        void FillContent(ScanItem s, PickupIndex idx)
        {
            if (!idx.isValid) return;
            var def = PickupCatalog.GetPickupDef(idx);
            if (def == null) return;
            s.content = Language.GetString(def.nameToken);
            s.contentColor = def.baseColor;
            var tmp = new Entry();
            SetPickupIcon(tmp, def, null, null);
            s.contentTex = tmp.tex;
            s.contentUv = tmp.uv;

            if (def.itemIndex != ItemIndex.None)
            {
                var idef = ItemCatalog.GetItemDef(def.itemIndex);
                s.group = idef != null ? TierGroup(idef.tier) : 6;
            }
            else if (def.equipmentIndex != EquipmentIndex.None)
                s.group = 7;
            else
                s.group = 6;
        }

        void RefreshScan()
        {
            scan.Clear();
            var body = Body;
            Vector3 me = body != null ? body.corePosition : Vector3.zero;

            foreach (var pi in InstanceTracker.GetInstancesList<PurchaseInteraction>())
            {
                if (pi == null) continue;
                if (freeInteract && pi.cost > 0) pi.cost = 0;
                if (!pi.available) continue;

                var s = new ScanItem();
                s.go = pi.gameObject;
                s.kind = 0;
                s.name = pi.GetDisplayName();
                if (string.IsNullOrEmpty(s.name)) continue;
                s.pos = pi.transform.position;
                s.cost = pi.cost > 0 ? (pi.costType == CostTypeIndex.Money ? "$" + pi.cost : pi.cost + " " + pi.costType) : "";

                var cb = pi.GetComponent<ChestBehavior>();
                if (cb != null) FillContent(s, cb.dropPickup);
                var st = pi.GetComponent<ShopTerminalBehavior>();
                if (st != null) FillContent(s, st.CurrentPickupIndex());

                s.dist = Vector3.Distance(me, s.pos);
                scan.Add(s);
            }

            foreach (var g in InstanceTracker.GetInstancesList<GenericPickupController>())
            {
                if (g == null || !g.pickupIndex.isValid) continue;
                var def = PickupCatalog.GetPickupDef(g.pickupIndex);
                if (def == null) continue;
                var s = new ScanItem();
                s.go = g.gameObject;
                s.kind = 1;
                s.name = Language.GetString(def.nameToken);
                s.color = def.baseColor;
                s.pos = g.transform.position;
                s.dist = Vector3.Distance(me, s.pos);
                FillContent(s, g.pickupIndex);
                scan.Add(s);
            }

            scan.Sort((a, b) => a.dist.CompareTo(b.dist));
            tpCache = FindTeleporterNow();
            if (open && tab == TTele) RefreshPortals(me);
        }

        // ---------- каталоги ----------
        static void SetSprite(Entry e, Sprite s)
        {
            if (s == null || s.texture == null) return;
            var t = s.texture;
            var r = s.textureRect;
            e.tex = t;
            e.uv = new Rect(r.x / t.width, r.y / t.height, r.width / t.width, r.height / t.height);
        }

        readonly Dictionary<string, Sprite> refCache = new Dictionary<string, Sprite>();

        Sprite LoadRef(UnityEngine.AddressableAssets.AssetReferenceT<Sprite> r)
        {
            if (r == null) return null;
            try
            {
                if (!r.RuntimeKeyIsValid()) return null;
                string key = r.RuntimeKey.ToString();
                Sprite s;
                if (refCache.TryGetValue(key, out s)) return s;
                if (r.IsValid()) s = r.Asset as Sprite;
                else s = r.LoadAssetAsync().WaitForCompletion();
                refCache[key] = s;
                return s;
            }
            catch (Exception ex)
            {
                Logger.LogWarning("icon load failed: " + ex.Message);
                return null;
            }
        }

        // Иконка: сначала готовая текстура пикапа (то, что рисует сам интерфейс игры), затем спрайты и ссылки на них.
        void SetPickupIcon(Entry e, PickupDef pd, Sprite own, UnityEngine.AddressableAssets.AssetReferenceT<Sprite> ownRef)
        {
            if (pd != null && pd.iconTexture != null)
            {
                e.tex = pd.iconTexture;
                e.uv = new Rect(0, 0, 1, 1);
                return;
            }
            if (pd != null) SetSprite(e, pd.iconSprite);
            if (e.tex == null) SetSprite(e, own);
            if (e.tex == null && pd != null) SetSprite(e, LoadRef(pd.iconSpriteReference));
            if (e.tex == null) SetSprite(e, LoadRef(ownRef));
        }

        static int TierGroup(ItemTier t)
        {
            string n = t.ToString();
            if (n.IndexOf("Void", StringComparison.Ordinal) >= 0) return 5;
            switch (t)
            {
                case ItemTier.Tier1: return 0;
                case ItemTier.Tier2: return 1;
                case ItemTier.Tier3: return 2;
                case ItemTier.Boss: return 3;
                case ItemTier.Lunar: return 4;
                default: return 6;
            }
        }

        void BuildCatalogs()
        {
            if (catalogsBuilt || ItemCatalog.itemCount <= 0 || EquipmentCatalog.equipmentCount <= 0) return;
            catalogsBuilt = true;

            items = Safe(BuildItems);
            equips = Safe(BuildEquipment);
            survivors = Safe(BuildSurvivors);
            allBodies = Safe(BuildAllBodies);
            enemies = Safe(BuildEnemies);
            drones = Safe(BuildDrones);
            scenes = Safe(BuildScenes);
        }

        void BuildMusicCatalog()
        {
            if (tracks == null && MusicTrackCatalog.musicTrackCount > 0)
                tracks = Safe(BuildTracks);
        }

        List<Entry> Safe(Func<List<Entry>> f)
        {
            try { return f(); }
            catch (Exception ex)
            {
                Logger.LogError(ex);
                return new List<Entry>();
            }
        }

        static void Finish(Entry e, string internalName)
        {
            e.search = (e.name + " " + internalName).ToLowerInvariant();
        }

        List<Entry> BuildItems()
        {
            var list = new List<Entry>();
            foreach (var d in ItemCatalog.allItemDefs)
            {
                if (d == null || d.hidden || string.IsNullOrEmpty(d.nameToken)) continue;
                var e = new Entry();
                e.name = Language.GetString(d.nameToken);
                e.color = ColorCatalog.GetColor(d.colorIndex);
                e.group = TierGroup(d.tier);
                e.data = d;
                SetPickupIcon(e, PickupCatalog.GetPickupDef(PickupCatalog.FindPickupIndex(d.itemIndex)), d.pickupIconSprite, d.pickupIconSpriteReference);
                Finish(e, d.name);
                list.Add(e);
            }
            Logger.LogInfo("Items: " + list.Count + ", with icon: " + list.Count(x => x.tex != null));
            return list.OrderBy(x => x.group).ThenBy(x => x.name).ToList();
        }

        List<Entry> BuildEquipment()
        {
            var list = new List<Entry>();
            foreach (var idx in EquipmentCatalog.allEquipment)
            {
                var d = EquipmentCatalog.GetEquipmentDef(idx);
                if (d == null || string.IsNullOrEmpty(d.nameToken)) continue;
                if (!(d.canDrop || d.isLunar || d.isBoss)) continue;
                var e = new Entry();
                e.name = Language.GetString(d.nameToken);
                e.color = ColorCatalog.GetColor(d.colorIndex);
                // 0 - обычное (оранжевое), 1 - лунное (синее), 2 - аспекты элиты и прочее
                e.group = d.isLunar ? 1 : (d.canDrop && !d.isBoss ? 0 : 2);
                e.data = d;
                SetPickupIcon(e, PickupCatalog.GetPickupDef(PickupCatalog.FindPickupIndex(idx)), d.pickupIconSprite, d.pickupIconSpriteReference);
                Finish(e, d.name);
                list.Add(e);
            }
            Logger.LogInfo("Equipment: " + list.Count + ", with icon: " + list.Count(x => x.tex != null));
            return list.OrderBy(x => x.group).ThenBy(x => x.name).ToList();
        }

        Entry BodyEntry(GameObject prefab)
        {
            var cb = prefab.GetComponent<CharacterBody>();
            var e = new Entry();
            e.prefab = prefab;
            e.name = cb != null ? cb.GetDisplayName() : prefab.name;
            if (cb != null && cb.portraitIcon != null) e.tex = cb.portraitIcon;
            Finish(e, prefab.name);
            return e;
        }

        List<Entry> BuildSurvivors()
        {
            var list = new List<Entry>();
            foreach (var s in SurvivorCatalog.allSurvivorDefs)
            {
                if (s == null || s.hidden || s.bodyPrefab == null) continue;
                var e = BodyEntry(s.bodyPrefab);
                e.name = Language.GetString(s.displayNameToken);
                Finish(e, s.bodyPrefab.name);
                e.data = s;
                e.group = (int)(s.desiredSortPosition * 100f);
                list.Add(e);
            }
            return list.OrderBy(x => x.group).ToList();
        }

        List<Entry> BuildAllBodies()
        {
            var list = new List<Entry>();
            foreach (var cb in BodyCatalog.allBodyPrefabBodyBodyComponents)
            {
                if (cb == null) continue;
                list.Add(BodyEntry(cb.gameObject));
            }
            return list.OrderBy(x => x.name).ToList();
        }

        List<Entry> BuildEnemies()
        {
            var list = new List<Entry>();
            foreach (var m in MasterCatalog.allAiMasters)
            {
                if (m == null || m.bodyPrefab == null) continue;
                var e = BodyEntry(m.bodyPrefab);
                e.prefab = m.gameObject; // для спавна нужен префаб мастера
                e.sub = m.name;
                Finish(e, m.name);
                list.Add(e);
            }
            return list.OrderBy(x => x.name).ToList();
        }

        List<Entry> BuildDrones()
        {
            var list = new List<Entry>();
            foreach (var d in DroneCatalog.allDroneDefs)
            {
                if (d == null || d.masterPrefab == null) continue;
                var e = new Entry();
                e.name = Language.GetString(d.nameToken);
                e.color = ColorCatalog.GetColor(d.color);
                e.prefab = d.masterPrefab;
                e.data = d;
                // 0 - серые (Tier1), 1 - зелёные (Tier2), 2 - красные (Tier3), 3 - прочие
                e.group = d.tier == ItemTier.Tier1 ? 0 : (d.tier == ItemTier.Tier2 ? 1 : (d.tier == ItemTier.Tier3 ? 2 : 3));
                if (d.iconTexture != null) e.tex = d.iconTexture;
                if (e.tex == null) SetSprite(e, d.GetIcon());
                if (e.tex == null) SetSprite(e, LoadRef(d.GetIconReference()));
                Finish(e, d.masterPrefab.name);
                list.Add(e);
            }
            return list.OrderBy(x => x.group).ThenBy(x => x.name).ToList();
        }

        List<Entry> BuildTracks()
        {
            var list = new List<Entry>();
            for (int i = 0; i < MusicTrackCatalog.musicTrackCount; i++)
            {
                var d = MusicTrackCatalog.GetMusicTrackDef((MusicTrackIndex)i);
                if (d == null) continue;
                var e = new Entry();
                e.name = d.cachedName;
                e.sub = string.IsNullOrEmpty(d.comment) ? "" : d.comment.Replace("\n", " ");
                e.extra = TrackLength(d);
                e.data = d;
                Finish(e, e.sub);
                list.Add(e);
            }
            return list.OrderBy(x => x.name).ToList();
        }

        // ---------- музыка ----------
        MusicTrackDef musicOverride;
        List<Entry> tracks;

        void PickTrack(MusicController mc, ref MusicTrackDef def)
        {
            if (musicOverride != null) def = musicOverride;
        }

        void PlayTrack(Entry e)
        {
            musicOverride = (MusicTrackDef)e.data;
            Say(T("Music: ", "Музыка: ", "Музика: ") + e.name);
        }

        void ResetMusic()
        {
            musicOverride = null;
            Say(T("Music reset to the stage default", "Музыка сброшена на стандартную для локации", "Музику скинуто на стандартну для локації"));
        }

        // ---------- недоступные (DLC) персонажи ----------
        // Выбор персонажа из дополнения, которого нет у игрока или которое выключено в забеге, ломает интерфейс и управление.
        string LockReason(GameObject prefab, SurvivorDef sd)
        {
            try
            {
                if (sd != null)
                {
                    if (!sd.CheckLocalUserHasRequiredEntitlement())
                        return T("DLC not owned", "DLC не куплено", "DLC не придбано");
                    var ex = sd.GetRequiredExpansion();
                    if (ex != null && Run.instance != null && !Run.instance.IsExpansionEnabled(ex))
                        return T("DLC disabled in this run", "DLC выключено в этом забеге", "DLC вимкнено в цьому забігу");
                }
                var rq = prefab != null ? prefab.GetComponent<RoR2.ExpansionManagement.ExpansionRequirementComponent>() : null;
                if (rq != null && rq.requiredExpansion != null && Run.instance != null
                    && !Run.instance.IsExpansionEnabled(rq.requiredExpansion))
                    return T("DLC disabled in this run", "DLC выключено в этом забеге", "DLC вимкнено в цьому забігу");
            }
            catch (Exception ex2)
            {
                Logger.LogWarning("LockReason: " + ex2.Message);
            }
            return null;
        }

        readonly Dictionary<List<Entry>, float> lockChecked = new Dictionary<List<Entry>, float>();

        void RefreshLocks(List<Entry> list)
        {
            if (list == null) return;
            float last;
            if (lockChecked.TryGetValue(list, out last) && Time.unscaledTime < last + 1f) return;
            lockChecked[list] = Time.unscaledTime;
            foreach (var e in list) e.lockWhy = LockReason(e.prefab, e.data as SurvivorDef);
        }

        List<Entry> BuildScenes()
        {
            var list = new List<Entry>();
            foreach (var s in SceneCatalog.allSceneDefs)
            {
                if (s == null || s.isOfflineScene || string.IsNullOrEmpty(s.nameToken)) continue;
                string type = s.sceneType.ToString();
                if (type != "Stage" && type != "Intermission") continue;
                var e = new Entry();
                e.name = Language.GetString(s.nameToken);
                e.sub = s.cachedName;
                e.data = s;
                if (s.previewTexture != null) e.tex = s.previewTexture;
                Finish(e, s.cachedName);
                list.Add(e);
            }
            return list.OrderBy(x => x.name).ToList();
        }
    }
}
