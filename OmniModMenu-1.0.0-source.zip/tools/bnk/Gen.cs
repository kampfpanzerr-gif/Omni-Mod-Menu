using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

class Obj { public byte type; public uint id; public byte[] data; }

class Gen
{
    static List<Obj> ReadHirc(byte[] b)
    {
        var objs = new List<Obj>();
        int p = 0;
        while (p + 8 <= b.Length)
        {
            string tag = Encoding.ASCII.GetString(b, p, 4);
            uint size = BitConverter.ToUInt32(b, p + 4);
            int body = p + 8;
            if (tag == "HIRC")
            {
                int q = body;
                uint n = BitConverter.ToUInt32(b, q); q += 4;
                for (uint i = 0; i < n; i++)
                {
                    byte t = b[q]; uint sz = BitConverter.ToUInt32(b, q + 1);
                    uint id = BitConverter.ToUInt32(b, q + 5);
                    var o = new Obj { type = t, id = id, data = new byte[sz - 4] };
                    Array.Copy(b, q + 9, o.data, 0, sz - 4);
                    objs.Add(o);
                    q += 5 + (int)sz;
                }
            }
            p = body + (int)size;
        }
        return objs;
    }

    static double SegmentDuration(byte[] d)
    {
        for (int off = 0; off + 12 <= d.Length; off++)
        {
            double dur = BitConverter.ToDouble(d, off);
            if (!(dur >= 500 && dur <= 3600000)) continue;
            uint n = BitConverter.ToUInt32(d, off + 8);
            if (n < 1 || n > 32) continue;
            int q = off + 12;
            bool ok = true;
            for (uint i = 0; i < n && ok; i++)
            {
                if (q + 12 > d.Length) { ok = false; break; }
                q += 12;
                while (q < d.Length && d[q] != 0) q++;
                if (q >= d.Length) { ok = false; break; }
                q++;
            }
            if (ok && q == d.Length) return dur;
        }
        return -1;
    }

    static Dictionary<uint, Obj> byId;
    static HashSet<uint> blocked = new HashSet<uint>();

    static void Collect(Obj o, int depth, HashSet<uint> visited, List<double> durs)
    {
        if (!visited.Add(o.id)) return;
        if (o.type == 10) { double d = SegmentDuration(o.data); if (d > 0) durs.Add(d); return; }
        if (depth >= 3 || (o.type != 12 && o.type != 13)) return;
        for (int q = 0; q + 4 <= o.data.Length; q++)
        {
            uint v = BitConverter.ToUInt32(o.data, q);
            Obj c;
            // в объекте также лежит id родителя (корневой переключатель), его пропускаем; плейлист ссылается только на сегменты
            if (v != o.id && !blocked.Contains(v) && byId.TryGetValue(v, out c) && (c.type == 10 || (o.type == 12 && (c.type == 12 || c.type == 13))))
                Collect(c, depth + 1, visited, durs);
        }
    }

    static void Main(string[] a)
    {
        var objs = ReadHirc(File.ReadAllBytes(a[0]));
        byId = new Dictionary<uint, Obj>();
        foreach (var o in objs) byId[o.id] = o;
        var allowed = new HashSet<string> { "gameplaySongChoice", "Music_menu", "Music_SolHrt" };
        var res = new SortedDictionary<uint, double>();
        var byName = new SortedDictionary<string, double>(StringComparer.Ordinal);

        // корневые переключатели: те, что напрямую содержат много состояний музыки
        var songIds = new List<uint>();
        foreach (var line in File.ReadAllLines(a[1]))
        {
            var p = line.Split('\t');
            uint sid;
            if (p.Length >= 4 && p[0] == "" && uint.TryParse(p[1], out sid) && allowed.Contains(p[3])) songIds.Add(sid);
        }
        foreach (var sw in objs.Where(o => o.type == 12))
        {
            int hits = 0;
            foreach (uint sid in songIds)
                for (int q = 0; q + 4 <= sw.data.Length; q++)
                    if (BitConverter.ToUInt32(sw.data, q) == sid) { hits++; break; }
            if (hits >= 5) blocked.Add(sw.id);
        }
        var names = new List<string>();
        foreach (var line in File.ReadAllLines(a[1]))
        {
            var p = line.Split('\t');
            uint id;
            if (!(p.Length >= 4 && p[0] == "" && uint.TryParse(p[1], out id) && allowed.Contains(p[3]) && p[2] != "None")) continue;
            double best = -1;
            foreach (var sw in objs.Where(o => o.type == 12))
            {
                for (int q = 0; q + 8 <= sw.data.Length; q++)
                {
                    if (BitConverter.ToUInt32(sw.data, q) != id) continue;
                    uint nid = BitConverter.ToUInt32(sw.data, q + 4);
                    Obj t;
                    if (!byId.TryGetValue(nid, out t) || (t.type != 10 && t.type != 12 && t.type != 13)) continue;
                    var durs = new List<double>();
                    Collect(t, 0, new HashSet<uint>(), durs);
                    if (durs.Count > 0) best = Math.Max(best, durs.Max());
                }
            }
            if (best > 0)
            {
                res[id] = Math.Round(best / 1000.0, 1);
                names.Add(p[3] + "/" + p[2] + " = " + res[id]);
                byName[p[2]] = res[id];
            }
        }
        // плоский словарь: ключи - id состояния Wwise и (запасной вариант) имя состояния
        var entries = new List<string>();
        foreach (var kv in res) entries.Add("  \"" + kv.Key + "\": " + kv.Value.ToString(System.Globalization.CultureInfo.InvariantCulture));
        foreach (var kv in byName) entries.Add("  \"" + kv.Key + "\": " + kv.Value.ToString(System.Globalization.CultureInfo.InvariantCulture));
        var sb = new StringBuilder("{\n" + string.Join(",\n", entries.ToArray()) + "\n}\n");
        File.WriteAllText(a[2], sb.ToString(), new UTF8Encoding(false));
        Console.WriteLine(res.Count + " songs");
        foreach (var n in names) Console.WriteLine(n);
    }
}
