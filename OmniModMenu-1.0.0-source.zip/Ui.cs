using System;
using System.Collections.Generic;
using System.Linq;
using RoR2;
using UnityEngine;

namespace RoR2ModMenu
{
    public partial class ModMenu
    {
        // ---------- состояние окна ----------
        bool open;
        Rect win = new Rect(60, 30, 1000, 720);
        bool dragging, resizing;
        Vector2 dragOff;
        int tab;
        readonly Vector2[] scrolls = new Vector2[20];
        float listViewH = 400f;

        // поиск / фильтры
        string itemSearch = "", equipSearch = "", charSearch = "", droneSearch = "", enemySearch = "", sceneSearch = "", scanSearch = "", musicSearch = "";
        string countStr = "1";
        int count = 1;
        string moneyStr = "10000";
        int tierMask = 127;
        bool ownedOnly;
        bool showAllBodies;
        int tpSub, spawnTeam = 2;

        // ---------- тема ----------
        static readonly Color cText = new Color(0.92f, 0.94f, 0.98f, 1f);
        static readonly Color cDim = new Color(0.58f, 0.63f, 0.72f, 1f);
        static readonly Color cOff = new Color(0.45f, 0.46f, 0.50f, 1f);

        Color cBg = new Color(0.075f, 0.085f, 0.115f), cPanel, cBtn, cBtnHover, cChip, cChipOn, cChipOnHover, cField, cFieldFocus, cTileInner, cRowA, cRowB;
        Color cAccent = new Color(0.22f, 0.62f, 0.95f), cAccentHover, cAccent2;
        string themeSig = "";

        // 0..6 - обычные, 7 - радуга, 8..10 - градиенты, 11 - свой цвет, 12 - свой градиент
        static readonly Color[] presetAccent =
        {
            new Color(0.22f, 0.62f, 0.95f), new Color(0.90f, 0.25f, 0.30f), new Color(0.18f, 0.76f, 0.50f), new Color(0.62f, 0.40f, 0.95f),
            new Color(0.98f, 0.68f, 0.15f), new Color(0.96f, 0.38f, 0.68f), new Color(0.75f, 0.78f, 0.85f)
        };
        static readonly Color[] gradA = { new Color(1f, 0.55f, 0.20f), new Color(0.20f, 0.60f, 1f), new Color(0.65f, 0.30f, 1f) };
        static readonly Color[] gradB = { new Color(0.95f, 0.25f, 0.55f), new Color(0.15f, 0.85f, 0.70f), new Color(0.10f, 0.90f, 1f) };
        static readonly Color[] bgPreset =
        {
            new Color(0.075f, 0.085f, 0.115f), new Color(0.03f, 0.03f, 0.035f), new Color(0.115f, 0.115f, 0.125f),
            new Color(0.045f, 0.075f, 0.16f), new Color(0.045f, 0.105f, 0.085f), new Color(0.125f, 0.055f, 0.085f)
        };

        string[] ThemeNames()
        {
            return new string[]
            {
                T("Default", "Стандартная", "Стандартна"), T("Crimson", "Багровая", "Багряна"), T("Emerald", "Изумрудная", "Смарагдова"),
                T("Violet", "Фиолетовая", "Фіолетова"), T("Amber", "Янтарная", "Бурштинова"), T("Rose", "Розовая", "Рожева"),
                T("Mono", "Монохром", "Монохром"), T("Rainbow", "Радуга", "Веселка"), T("Sunset", "Закат", "Захід сонця"),
                T("Ocean", "Океан", "Океан"), T("Neon", "Неон", "Неон"), T("Custom color", "Свой цвет", "Свій колір"),
                T("Custom gradient", "Свой градиент", "Свій градієнт")
            };
        }

        string[] BgNames()
        {
            return new string[]
            {
                T("Midnight", "Полночь", "Північ"), T("Black", "Чёрный", "Чорний"), T("Graphite", "Графит", "Графіт"),
                T("Navy", "Тёмно-синий", "Темно-синій"), T("Forest", "Лесной", "Лісовий"), T("Wine", "Винный", "Винний"),
                T("Custom", "Свой", "Свій")
            };
        }

        static string ToHex(Color c)
        {
            return ((int)(Mathf.Clamp01(c.r) * 255f)).ToString("X2") + ((int)(Mathf.Clamp01(c.g) * 255f)).ToString("X2") + ((int)(Mathf.Clamp01(c.b) * 255f)).ToString("X2");
        }

        static Color FromHex(string hex, Color fallback)
        {
            if (string.IsNullOrEmpty(hex) || hex.Length != 6) return fallback;
            try
            {
                return new Color(Convert.ToInt32(hex.Substring(0, 2), 16) / 255f, Convert.ToInt32(hex.Substring(2, 2), 16) / 255f, Convert.ToInt32(hex.Substring(4, 2), 16) / 255f);
            }
            catch (Exception) { return fallback; }
        }

        static Color Lift(Color c, float d)
        {
            return new Color(Mathf.Clamp01(c.r + d), Mathf.Clamp01(c.g + d), Mathf.Clamp01(c.b + d), 1f);
        }

        static string Key(Color c)
        {
            return ToHex(c);
        }

        void UpdateTheme()
        {
            float t = Time.unscaledTime;
            int th = Mathf.Clamp(cfgTheme.Value, 0, 12);
            Color a, a2;
            if (th <= 6) { a = presetAccent[th]; a2 = Color.Lerp(a, Color.white, 0.3f); }
            else if (th == 7)
            {
                float h = Mathf.Round(Mathf.Repeat(t * 0.08f, 1f) * 90f) / 90f;
                a = Color.HSVToRGB(h, 0.65f, 1f);
                a2 = Color.HSVToRGB(Mathf.Repeat(h + 0.14f, 1f), 0.65f, 1f);
            }
            else if (th <= 10 || th == 12)
            {
                Color ca = th == 12 ? FromHex(cfgGradAHex.Value, gradA[0]) : gradA[th - 8];
                Color cb = th == 12 ? FromHex(cfgGradBHex.Value, gradB[0]) : gradB[th - 8];
                float k = Mathf.Round(Mathf.PingPong(t * 0.25f, 1f) * 60f) / 60f;
                a = Color.Lerp(ca, cb, k);
                a2 = Color.Lerp(cb, ca, k);
            }
            else { a = FromHex(cfgAccentHex.Value, presetAccent[0]); a2 = Color.Lerp(a, Color.white, 0.3f); }

            int bt = Mathf.Clamp(cfgBgTheme.Value, 0, 6);
            Color bg = bt == 6 ? FromHex(cfgBgHex.Value, bgPreset[0]) : bgPreset[bt];

            string sig = Key(a) + Key(a2) + Key(bg);
            if (sig == themeSig) return;
            themeSig = sig;
            cAccent = a; cAccent2 = a2; cBg = bg;
            cAccentHover = Color.Lerp(a, Color.white, 0.25f);
            cPanel = Lift(bg, 0.03f);
            cBtn = Lift(bg, 0.105f);
            cBtnHover = Lift(bg, 0.18f);
            cChip = Lift(bg, 0.065f);
            cChipOn = Lift(bg, 0.19f);
            cChipOnHover = Lift(bg, 0.25f);
            cField = Lift(bg, -0.02f);
            cFieldFocus = Lift(bg, 0.015f);
            cTileInner = Lift(bg, -0.015f);
            cRowA = Lift(bg, 0.055f);
            cRowB = Lift(bg, 0.075f);
            RebuildStyles();
        }

        // ---------- текстуры и стили ----------
        GUISkin defaultSkin, skin;
        GUIStyle sWin, sPanel, sBtn, sBtnAccent, sBtnOff, sTab, sTabOn, sLabel, sDim, sTitle, sHeader, sWrap, sField, sSwitch, sChip, sEsp, sEspBg, sSmallBtn, sFlat, sFlatSm, sDot;
        Texture2D tCursor, tGrad;
        readonly List<Texture2D> texPool = new List<Texture2D>();

        void RebuildStyles()
        {
            foreach (var t in texPool) if (t != null) UnityEngine.Object.Destroy(t);
            texPool.Clear();
            skin = null;
            sFps = null;
        }

        // Индексы вкладок
        const int TPlayer = 0, TPlayers = 1, TItems = 2, TEquip = 3, TChar = 4, TTele = 5, TDrones = 6, TSpawn = 7,
                  TStats = 8, TScan = 9, TWorld = 10, TMusic = 11, TSet = 12;

        static bool InPoly(Vector2[] p, float x, float y)
        {
            bool inside = false;
            for (int i = 0, j = p.Length - 1; i < p.Length; j = i++)
            {
                if (((p[i].y > y) != (p[j].y > y)) && (x < (p[j].x - p[i].x) * (y - p[i].y) / (p[j].y - p[i].y) + p[i].x))
                    inside = !inside;
            }
            return inside;
        }

        // Стрелка-курсор: белая заливка, чёрная обводка (рисуется программно).
        static Texture2D MakeCursor()
        {
            const int size = 28;
            var poly = new Vector2[]
            {
                new Vector2(2, 2), new Vector2(2, 21), new Vector2(7, 17), new Vector2(11, 25),
                new Vector2(15, 23), new Vector2(11, 15.5f), new Vector2(17.5f, 15.5f)
            };
            var t = new Texture2D(size, size, TextureFormat.RGBA32, false);
            t.hideFlags = HideFlags.HideAndDontSave;
            t.filterMode = FilterMode.Bilinear;
            t.wrapMode = TextureWrapMode.Clamp;
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float px = x + 0.5f, py = y + 0.5f;
                    bool fill = InPoly(poly, px, py);
                    bool edge = false;
                    if (!fill)
                    {
                        for (int oy = -1; oy <= 1 && !edge; oy++)
                            for (int ox = -1; ox <= 1; ox++)
                                if (InPoly(poly, px + ox * 1.3f, py + oy * 1.3f)) { edge = true; break; }
                    }
                    Color c = fill ? Color.white : (edge ? Color.black : new Color(0, 0, 0, 0));
                    t.SetPixel(x, size - 1 - y, c);
                }
            }
            t.Apply();
            return t;
        }

        // Скруглённый прямоугольник со сглаживанием краёв (3x3 суперсэмплинг). Используется как 9-slice,
        // поэтому углы остаются чёткими при любом размере рамки.
        Texture2D Round(Color c, int radius, int size)
        {
            var t = new Texture2D(size, size, TextureFormat.RGBA32, false);
            t.hideFlags = HideFlags.HideAndDontSave;
            t.filterMode = FilterMode.Bilinear;
            t.wrapMode = TextureWrapMode.Clamp;
            float r2 = radius * radius;
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float cov = 0f;
                    for (int sy = 0; sy < 3; sy++)
                    {
                        for (int sx = 0; sx < 3; sx++)
                        {
                            float px = x + (sx + 0.5f) / 3f, py = y + (sy + 0.5f) / 3f;
                            float dx = Mathf.Max(Mathf.Max(radius - px, px - (size - radius)), 0f);
                            float dy = Mathf.Max(Mathf.Max(radius - py, py - (size - radius)), 0f);
                            if (dx * dx + dy * dy <= r2) cov += 1f / 9f;
                        }
                    }
                    t.SetPixel(x, y, new Color(c.r, c.g, c.b, c.a * cov));
                }
            }
            t.Apply();
            texPool.Add(t);
            return t;
        }

        static void TextColor(GUIStyle s, Color c)
        {
            s.normal.textColor = c; s.hover.textColor = c; s.active.textColor = c; s.focused.textColor = c;
            s.onNormal.textColor = c; s.onHover.textColor = c; s.onActive.textColor = c; s.onFocused.textColor = c;
        }

        static void Backgrounds(GUIStyle s, Texture2D n, Texture2D h, Texture2D a, Texture2D on, Texture2D onHover, int radius)
        {
            s.normal.background = n; s.hover.background = h; s.active.background = a; s.focused.background = n;
            s.onNormal.background = on; s.onHover.background = onHover; s.onActive.background = on; s.onFocused.background = on;
            s.border = new RectOffset(radius, radius, radius, radius);
        }

        GUIStyle MakeBtn(Color n, Color h, Color on, Color onH, int fontSize, TextAnchor anchor)
        {
            var s = new GUIStyle(skin.button);
            Backgrounds(s, Round(n, 6, 16), Round(h, 6, 16), Round(on, 6, 16), Round(on, 6, 16), Round(onH, 6, 16), 6);
            TextColor(s, cText);
            s.fontSize = fontSize;
            s.alignment = anchor;
            s.padding = new RectOffset(10, 10, 4, 4);
            s.margin = new RectOffset(2, 2, 2, 2);
            s.clipping = TextClipping.Clip;
            return s;
        }

        void EnsureStyles()
        {
            if (skin != null) return;
            if (defaultSkin == null) defaultSkin = GUI.skin;
            skin = UnityEngine.Object.Instantiate(defaultSkin);
            skin.settings.cursorColor = cAccent;
            skin.settings.selectionColor = new Color(cAccent.r, cAccent.g, cAccent.b, 0.4f);

            sFlat = new GUIStyle();
            sFlat.normal.background = Round(Color.white, 6, 16);
            sFlat.border = new RectOffset(6, 6, 6, 6);
            sFlatSm = new GUIStyle();
            sFlatSm.normal.background = Round(Color.white, 4, 12);
            sFlatSm.border = new RectOffset(4, 4, 4, 4);
            sDot = new GUIStyle();
            sDot.normal.background = Round(Color.white, 5, 10);
            sDot.border = new RectOffset(5, 5, 5, 5);

            tGrad = new Texture2D(64, 1, TextureFormat.RGBA32, false);
            tGrad.hideFlags = HideFlags.HideAndDontSave;
            tGrad.wrapMode = TextureWrapMode.Clamp;
            for (int i = 0; i < 64; i++) tGrad.SetPixel(i, 0, Color.Lerp(cAccent, cAccent2, i / 63f));
            tGrad.Apply();
            texPool.Add(tGrad);

            sWin = new GUIStyle(skin.box);
            sWin.normal.background = Round(cBg, 12, 32);
            sWin.border = new RectOffset(12, 12, 12, 12);
            sWin.padding = new RectOffset(0, 0, 0, 0);
            sWin.margin = new RectOffset(0, 0, 0, 0);

            sPanel = new GUIStyle(skin.box);
            sPanel.normal.background = Round(cPanel, 10, 28);
            sPanel.border = new RectOffset(10, 10, 10, 10);

            sBtn = MakeBtn(cBtn, cBtnHover, cAccent, cAccentHover, 13, TextAnchor.MiddleCenter);
            sBtnAccent = MakeBtn(cAccent, cAccentHover, cAccent, cAccentHover, 13, TextAnchor.MiddleCenter);
            sBtnOff = MakeBtn(Lift(cBg, 0.07f), Lift(cBg, 0.07f), Lift(cBg, 0.07f), Lift(cBg, 0.07f), 13, TextAnchor.MiddleCenter);
            TextColor(sBtnOff, cOff);
            sSmallBtn = MakeBtn(cBtn, cBtnHover, cAccent, cAccentHover, 15, TextAnchor.MiddleCenter);
            sSmallBtn.padding = new RectOffset(2, 2, 0, 2);
            sSwitch = MakeBtn(cBtn, cBtnHover, cAccent, cAccentHover, 13, TextAnchor.MiddleCenter);
            sChip = MakeBtn(cChip, cBtnHover, cChipOn, cChipOnHover, 12, TextAnchor.MiddleCenter);
            sTab = MakeBtn(new Color(0, 0, 0, 0), new Color(1, 1, 1, 0.08f), cAccent, cAccentHover, 14, TextAnchor.MiddleLeft);
            sTab.padding = new RectOffset(16, 8, 6, 6);
            sTabOn = MakeBtn(cAccent, cAccentHover, cAccent, cAccentHover, 14, TextAnchor.MiddleLeft);
            sTabOn.padding = new RectOffset(16, 8, 6, 6);

            sLabel = new GUIStyle(skin.label);
            sLabel.fontSize = 13; sLabel.alignment = TextAnchor.MiddleLeft; sLabel.clipping = TextClipping.Clip;
            TextColor(sLabel, cText);
            sDim = new GUIStyle(sLabel);
            sDim.fontSize = 12;
            TextColor(sDim, cDim);
            sTitle = new GUIStyle(sLabel);
            sTitle.fontSize = 15; sTitle.fontStyle = FontStyle.Bold;
            TextColor(sTitle, cAccentHover);
            sHeader = new GUIStyle(sTitle);
            TextColor(sHeader, Color.white);
            sWrap = new GUIStyle(sLabel);
            sWrap.wordWrap = true; sWrap.alignment = TextAnchor.UpperLeft; sWrap.clipping = TextClipping.Overflow;

            sField = new GUIStyle(skin.textField);
            var fieldBg = Round(cField, 6, 16);
            var fieldFocus = Round(cFieldFocus, 6, 16);
            sField.normal.background = fieldBg; sField.hover.background = fieldBg;
            sField.active.background = fieldFocus; sField.focused.background = fieldFocus;
            sField.border = new RectOffset(6, 6, 6, 6);
            sField.padding = new RectOffset(8, 8, 5, 5);
            sField.fontSize = 13;
            TextColor(sField, cText);

            sEsp = new GUIStyle(sLabel);
            sEsp.fontSize = 12; sEsp.fontStyle = FontStyle.Bold; sEsp.alignment = TextAnchor.UpperLeft; sEsp.clipping = TextClipping.Overflow;
            sEspBg = new GUIStyle(skin.box);
            sEspBg.normal.background = Round(new Color(0.05f, 0.06f, 0.09f, 0.78f), 5, 14);
            sEspBg.border = new RectOffset(5, 5, 5, 5);

            // слайдеры
            skin.horizontalSlider.normal.background = Round(cField, 3, 8);
            skin.horizontalSlider.border = new RectOffset(3, 3, 3, 3);
            skin.horizontalSlider.fixedHeight = 8;
            skin.horizontalSlider.margin = new RectOffset(4, 4, 10, 10);
            skin.horizontalSliderThumb.normal.background = Round(cAccent, 8, 16);
            skin.horizontalSliderThumb.hover.background = Round(cAccentHover, 8, 16);
            skin.horizontalSliderThumb.active.background = Round(cAccentHover, 8, 16);
            skin.horizontalSliderThumb.border = new RectOffset(8, 8, 8, 8);
            skin.horizontalSliderThumb.fixedWidth = 16;
            skin.horizontalSliderThumb.fixedHeight = 16;
            skin.horizontalSliderThumb.margin = new RectOffset(0, 0, 0, 0);

            // скроллбар
            skin.verticalScrollbar.normal.background = Round(cField, 4, 10);
            skin.verticalScrollbar.border = new RectOffset(4, 4, 4, 4);
            skin.verticalScrollbar.fixedWidth = 10;
            skin.verticalScrollbarThumb.normal.background = Round(cChipOn, 4, 10);
            skin.verticalScrollbarThumb.hover.background = Round(cAccent, 4, 10);
            skin.verticalScrollbarThumb.active.background = Round(cAccentHover, 4, 10);
            skin.verticalScrollbarThumb.border = new RectOffset(4, 4, 4, 4);
            skin.verticalScrollbarThumb.fixedWidth = 10;
            skin.verticalScrollbarUpButton.fixedHeight = 0; skin.verticalScrollbarUpButton.fixedWidth = 0;
            skin.verticalScrollbarDownButton.fixedHeight = 0; skin.verticalScrollbarDownButton.fixedWidth = 0;
            skin.horizontalScrollbar.fixedHeight = 0;
            skin.horizontalScrollbarThumb.fixedHeight = 0;
            skin.horizontalScrollbarLeftButton.fixedWidth = 0; skin.horizontalScrollbarRightButton.fixedWidth = 0;
        }

        // ---------- вспомогательные элементы ----------
        bool Btn(string text, params GUILayoutOption[] o) { return GUILayout.Button(text, sBtn, Fit(text, sBtn, o)); }
        bool BtnA(string text, params GUILayoutOption[] o) { return GUILayout.Button(text, sBtnAccent, Fit(text, sBtnAccent, o)); }

        // Кнопка в строке списка: одинаковый размер, по центру строки по высоте (справа налево: 0, 1, ...)
        static Rect RowBtnAt(Rect r, int fromRight)
        {
            return new Rect(r.xMax - 142f - fromRight * 138f, r.y + (r.height - 28f) / 2f, 132f, 28f);
        }

        static Rect RowBtn(Rect r) { return RowBtnAt(r, 0); }

        static System.Reflection.FieldInfo optType, optValue;

        // Если перевод длиннее заданной ширины кнопки, расширяем её ровно настолько, чтобы текст не обрезался.
        static GUILayoutOption[] Fit(string text, GUIStyle style, GUILayoutOption[] o)
        {
            if (o == null || o.Length == 0) return o;
            try
            {
                if (optType == null)
                {
                    var t = typeof(GUILayoutOption);
                    var f = System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance;
                    optType = t.GetField("type", f);
                    optValue = t.GetField("value", f);
                }
                if (optType == null || optValue == null) return o;
                var res = (GUILayoutOption[])o.Clone();
                for (int i = 0; i < res.Length; i++)
                {
                    if (optType.GetValue(res[i]).ToString() != "fixedWidth") continue;
                    float w = Convert.ToSingle(optValue.GetValue(res[i]));
                    float need = style.CalcSize(new GUIContent(text)).x + 4f;
                    if (need > w) res[i] = GUILayout.Width(need);
                }
                return res;
            }
            catch (Exception) { return o; }
        }
        // Переключатель: ширина по тексту (но не меньше 260), текст по центру, как у обычных кнопок
        bool Sw(bool v, string text)
        {
            float w = Mathf.Max(260f, sSwitch.CalcSize(new GUIContent(text)).x + 30f);
            return GUILayout.Toggle(v, text, sSwitch, GUILayout.Height(28), GUILayout.Width(w));
        }
        void Section(string text) { GUILayout.Space(6); GUILayout.Label(text, sTitle); }
        void Dim(string text) { GUILayout.Label(text, sDim); }

        float SliderRow(string label, float v, float min, float max, string fmt)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label(label, sLabel, GUILayout.Width(190));
            v = GUILayout.HorizontalSlider(v, min, max, GUILayout.MinWidth(120));
            GUILayout.Label(v.ToString(fmt), sLabel, GUILayout.Width(60));
            GUILayout.EndHorizontal();
            return v;
        }

        // Ползунок с кнопкой сброса на значение по умолчанию
        float SliderRowReset(string label, float v, float min, float max, string fmt, float def)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label(label, sLabel, GUILayout.Width(190));
            v = GUILayout.HorizontalSlider(v, min, max, GUILayout.MinWidth(120));
            GUILayout.Label(v.ToString(fmt), sLabel, GUILayout.Width(60));
            if (GUILayout.Button(T("Reset", "Сброс", "Скинути"), sChip, GUILayout.Width(130), GUILayout.Height(28))) v = def;
            GUILayout.EndHorizontal();
            return v;
        }

        string SearchField(string value)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label(T("Search", "Поиск", "Пошук"), sDim, GUILayout.Width(52));
            value = GUILayout.TextField(value, sField, GUILayout.Height(28));
            if (value.Length > 0 && GUILayout.Button("x", sSmallBtn, GUILayout.Width(28), GUILayout.Height(28))) value = "";
            GUILayout.EndHorizontal();
            return value;
        }

        void CountRow()
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label(T("Amount", "Количество", "Кількість"), sDim, GUILayout.Width(80));
            countStr = GUILayout.TextField(countStr, sField, GUILayout.Width(80), GUILayout.Height(28));
            int p;
            if (int.TryParse(countStr, out p) && p > 0) count = p;
            int[] presets = { 1, 5, 10, 50, 100, 1000 };
            foreach (int n in presets)
                if (GUILayout.Button(n.ToString(), sChip, GUILayout.Width(64), GUILayout.Height(28))) { count = n; countStr = n.ToString(); }
            GUILayout.EndHorizontal();
        }

        static Rect Inset(Rect r, float d) { return new Rect(r.x + d, r.y + d, r.width - d * 2, r.height - d * 2); }

        // Рамка иконки: два вложенных скруглённых прямоугольника (9-slice, без растягивания текстуры).
        void DrawTile(Rect r, Color border, Texture tex, Rect uv)
        {
            if (Event.current.type != EventType.Repaint) return;
            var old = GUI.color;
            GUI.color = new Color(border.r, border.g, border.b, 0.95f);
            GUI.Box(r, GUIContent.none, sFlat);
            GUI.color = cTileInner;
            GUI.Box(Inset(r, 2f), GUIContent.none, sFlatSm);
            GUI.color = Color.white;
            if (tex != null) GUI.DrawTextureWithTexCoords(Inset(r, 5f), tex, uv);
            GUI.color = old;
        }

        delegate void RowDraw(Entry e, Rect r);

        void ListView(int slot, List<Entry> list, float rowH, RowDraw draw)
        {
            scrolls[slot] = GUILayout.BeginScrollView(scrolls[slot], GUILayout.ExpandHeight(true));
            Rect total = GUILayoutUtility.GetRect(1f, Mathf.Max(1f, list.Count * rowH), GUILayout.ExpandWidth(true));
            int first = Mathf.Max(0, (int)(scrolls[slot].y / rowH));
            int last = Mathf.Min(list.Count, first + (int)(listViewH / rowH) + 2);
            for (int i = first; i < last; i++)
            {
                var r = new Rect(total.x, total.y + i * rowH, total.width, rowH - 2f);
                var e = list[i];
                if (e.header)
                {
                    if (Event.current.type == EventType.Repaint)
                    {
                        var oc = GUI.color;
                        GUI.color = new Color(e.color.r, e.color.g, e.color.b, 0.9f);
                        GUI.Box(new Rect(r.x + 4, r.yMax - 5, r.width - 8, 3), GUIContent.none, sFlatSm);
                        GUI.color = oc;
                    }
                    var oldc = GUI.contentColor;
                    GUI.contentColor = e.color;
                    GUI.Label(new Rect(r.x + 8, r.y + 6, r.width - 16, 26), e.name, sHeader);
                    GUI.contentColor = oldc;
                    continue;
                }
                if (Event.current.type == EventType.Repaint)
                {
                    var old = GUI.color;
                    GUI.color = (i & 1) == 0 ? cRowA : cRowB;
                    GUI.Box(r, GUIContent.none, sFlat);
                    if (r.Contains(Event.current.mousePosition) && GUI.enabled)
                    {
                        GUI.color = new Color(1, 1, 1, 0.07f);
                        GUI.Box(r, GUIContent.none, sFlat);
                    }
                    GUI.color = old;
                }
                draw(e, r);
            }
            GUILayout.EndScrollView();
            if (Event.current.type == EventType.Repaint)
            {
                float h = GUILayoutUtility.GetLastRect().height;
                if (h > 50f) listViewH = h;
            }
        }

        static List<Entry> Filter(List<Entry> src, string q)
        {
            if (src == null) return new List<Entry>();
            q = q.Trim().ToLowerInvariant();
            if (q.Length == 0) return src;
            return src.Where(e => e.search.IndexOf(q, StringComparison.Ordinal) >= 0).ToList();
        }

        // Вставляет заголовки в уже отсортированный по группам список.
        static List<Entry> WithHeaders(List<Entry> sorted, Func<Entry, int> group, Func<int, string> title)
        {
            var res = new List<Entry>();
            int last = int.MinValue;
            foreach (var e in sorted)
            {
                int g = group(e);
                if (g != last)
                {
                    var h = new Entry();
                    h.header = true;
                    h.name = title(g);
                    h.color = e.color;
                    res.Add(h);
                    last = g;
                }
                res.Add(e);
            }
            return res;
        }

        void RowHead(Entry e, Rect r, string sub, bool dim, bool noTile)
        {
            float x = r.x + 10;
            if (!noTile)
            {
                DrawTile(new Rect(r.x + 4, r.y + 3, r.height - 6, r.height - 6), dim ? cOff : e.color, e.tex, e.uv);
                x = r.x + r.height + 4;
            }
            var old = GUI.contentColor;
            GUI.contentColor = dim ? cOff : e.color;
            GUI.Label(new Rect(x, r.y + 2, 360, 22), e.name, sLabel);
            GUI.contentColor = old;
            if (!string.IsNullOrEmpty(sub)) GUI.Label(new Rect(x, r.y + 22, 420, 18), sub, sDim);
        }

        void RowHead(Entry e, Rect r, string sub) { RowHead(e, r, sub, false, false); }

        // ---------- главное окно ----------
        string[] TabNames()
        {
            return new string[]
            {
                T("Player", "Игрок", "Гравець"),
                T("Players", "Игроки", "Гравці"),
                T("Items", "Предметы", "Предмети"),
                T("Equipment", "Снаряжение", "Спорядження"),
                T("Character", "Персонаж", "Персонаж"),
                T("Teleport", "Телепорт", "Телепорт"),
                T("Drones", "Дроны", "Дрони"),
                T("Spawn", "Спавн", "Спавн"),
                T("Stats", "Статы", "Стати"),
                T("Scanner", "Сканер", "Сканер"),
                T("World", "Мир", "Світ"),
                T("Music", "Музыка", "Музика"),
                T("Settings", "Настройки", "Налаштування")
            };
        }

        void OnGUI()
        {
            bool hudShow = cfgHud.Value && (cfgHudMode.Value == 1 || open);
            if (!open && !espOn && !hudShow && !cfgFps.Value && !cfgPing.Value && !espEnemies && !espPlayers) return;
            if (defaultSkin == null) defaultSkin = GUI.skin;
            if (Event.current.type == EventType.Layout) UpdateTheme();
            EnsureStyles();
            var oldSkin = GUI.skin;
            GUI.skin = skin;
            GUI.depth = -10000;

            if (espOn) DrawEsp();
            if (hudShow) DrawHud();
            if (cfgFps.Value || cfgPing.Value) DrawStats();
            if (espEnemies || espPlayers) DrawEntityEsp();
            if (open)
            {
                BuildCatalogs();
                BuildMusicCatalog();
                var oldM = GUI.matrix;
                float sc = cfgScale.Value;
                GUI.matrix = Matrix4x4.Scale(new Vector3(sc, sc, 1f));
                DrawWindow(sc);
                GUI.matrix = oldM;

                // курсор игры рисуется под IMGUI, поэтому рисуем свой поверх окна
                if (Event.current.type == EventType.Repaint)
                {
                    if (tCursor == null) tCursor = MakeCursor();
                    var mp = Input.mousePosition;
                    var oc = GUI.color;
                    GUI.color = Color.white;
                    GUI.DrawTexture(new Rect(mp.x - 2, Screen.height - mp.y - 2, 28, 28), tCursor);
                    GUI.color = oc;
                }
            }
            GUI.skin = oldSkin;
        }

        void DrawWindow(float sc)
        {
            HandleBindCapture();

            float sw = Screen.width / sc, sh = Screen.height / sc;
            win.width = Mathf.Clamp(win.width, 780f, sw);
            win.height = Mathf.Clamp(win.height, 560f, sh);
            win.x = Mathf.Clamp(win.x, 0f, Mathf.Max(0f, sw - win.width));
            win.y = Mathf.Clamp(win.y, 0f, Mathf.Max(0f, sh - win.height));

            var oldC = GUI.color;
            GUI.color = new Color(1, 1, 1, cfgOpacity.Value);
            GUI.Box(win, GUIContent.none, sWin);
            GUI.color = oldC;

            // перетаскивание и изменение размера
            var e = Event.current;
            // перетаскивать окно можно за заголовок слева; область с поиском и языками не трогаем
            var dragRect = new Rect(win.x, win.y, 270, 42);
            var dragRect2 = new Rect(win.x + 280 + Mathf.Min(340f, win.width - 280f - 250f) + 36f, win.y, Mathf.Max(0f, win.width - 230f - (280f + Mathf.Min(340f, win.width - 280f - 250f) + 36f)), 42);
            var grip = new Rect(win.xMax - 22, win.yMax - 22, 22, 22);
            if (pend == null)
            {
                if (e.type == EventType.MouseDown && grip.Contains(e.mousePosition)) { resizing = true; e.Use(); }
                else if (e.type == EventType.MouseDown && (dragRect.Contains(e.mousePosition) || dragRect2.Contains(e.mousePosition))) { dragging = true; dragOff = e.mousePosition - new Vector2(win.x, win.y); e.Use(); }
                else if (e.type == EventType.MouseDrag && dragging) { win.x = e.mousePosition.x - dragOff.x; win.y = e.mousePosition.y - dragOff.y; e.Use(); }
                else if (e.type == EventType.MouseDrag && resizing) { win.width = e.mousePosition.x - win.x + 10; win.height = e.mousePosition.y - win.y + 10; e.Use(); }
            }
            if (e.type == EventType.MouseUp) { dragging = false; resizing = false; }

            GUI.enabled = pend == null;

            // заголовок
            GUI.Label(new Rect(win.x + 18, win.y + 8, 400, 28), "Omni Mod Menu", sTitle);
            GUI.Label(new Rect(win.x + 160, win.y + 11, 110, 24), KeyText(binds[0].k1.Value) + " - " + T("hide", "скрыть", "сховати"), sDim);

            // глобальный поиск по функциям, предметам и прочему
            float sx = win.x + 280, sw0 = Mathf.Min(340f, win.width - 280f - 250f);
            if (sw0 > 120f)
            {
                GUI.Label(new Rect(sx, win.y + 11, 70, 24), T("Search", "Поиск", "Пошук"), sDim);
                globalSearch = GUI.TextField(new Rect(sx + 60, win.y + 8, sw0 - 60, 26), globalSearch, sField);
                if (globalSearch.Length > 0 && GUI.Button(new Rect(sx + sw0 + 4, win.y + 7, 28, 28), "x", sSmallBtn)) globalSearch = "";
            }
            for (int i = 0; i < 3; i++)
            {
                var r = new Rect(win.xMax - 196 + i * 50, win.y + 8, 46, 26);
                if (GUI.Toggle(r, lang == i, i == 1 ? "UA" : LangCodes[i].ToUpperInvariant(), sChip) && lang != i) SetLanguage(i);
            }
            if (GUI.Button(new Rect(win.xMax - 40, win.y + 7, 30, 28), "x", sSmallBtn)) open = false;
            if (Event.current.type == EventType.Repaint)
            {
                var g = GUI.color;
                GUI.color = Color.white;
                GUI.DrawTexture(new Rect(win.x + 14, win.y + 41, win.width - 28, 3), tGrad);
                GUI.color = g;
            }

            // боковая панель
            string[] names = TabNames();
            for (int i = 0; i < names.Length; i++)
            {
                var r = new Rect(win.x + 12, win.y + 54 + i * 36, 160, 32);
                if (GUI.Button(r, names[i], i == tab && globalSearch.Trim().Length == 0 ? sTabOn : sTab)) { tab = i; globalSearch = ""; }
            }

            // содержимое
            var content = new Rect(win.x + 184, win.y + 52, win.width - 196, win.height - 52 - 36);
            GUI.Box(content, GUIContent.none, sPanel);
            GUILayout.BeginArea(Inset(content, 12f));
            bool searching = globalSearch.Trim().Length > 0;
            if (!searching && Body == null && tab != TScan && tab != TWorld && tab != TMusic && tab != TSet)
                GUILayout.Label(T("No character - start a run.", "Нет персонажа - зайдите в забег.", "Немає персонажа - почніть забіг."), sDim);
            if (searching) TabSearch();
            else switch (tab)
            {
                case TPlayer: TabPlayer(); break;
                case TPlayers: TabPlayers(); break;
                case TItems: TabItems(); break;
                case TEquip: TabEquipment(); break;
                case TChar: TabCharacter(); break;
                case TTele: TabTeleport(); break;
                case TDrones: TabDrones(); break;
                case TSpawn: TabSpawn(); break;
                case TStats: TabStats(); break;
                case TScan: TabScanner(); break;
                case TWorld: TabWorld(); break;
                case TMusic: TabMusic(); break;
                case TSet: TabSettings(); break;
            }
            GUILayout.EndArea();

            // статус и ручка размера
            string msg = Time.unscaledTime < statusUntil ? status : "";
            if (bwAction >= 0) msg = T("Press a key to bind (Esc - cancel)...", "Нажмите клавишу для привязки (Esc - отмена)...", "Натисніть клавішу для прив'язки (Esc - скасувати)...");
            GUI.Label(new Rect(win.x + 190, win.yMax - 30, win.width - 230, 24), msg, sLabel);
            var oc = GUI.color;
            GUI.color = cDim;
            GUI.Box(new Rect(win.xMax - 16, win.yMax - 16, 10, 10), GUIContent.none, sFlatSm);
            GUI.color = oc;

            GUI.enabled = true;
            if (pend != null) DrawPendingDialog();
        }

        void DrawPendingDialog()
        {
            var oc = GUI.color;
            GUI.color = new Color(0, 0, 0, 0.6f);
            GUI.Box(win, GUIContent.none, sWin);
            GUI.color = oc;
            var m = new Rect(win.center.x - 270, win.center.y - 110, 540, 220);
            GUI.Box(m, GUIContent.none, sPanel);
            GUI.Label(new Rect(m.x + 20, m.y + 14, m.width - 40, 26), T("Key already in use", "Клавиша уже используется", "Клавіша вже використовується"), sTitle);
            string text = T("The key {0} is already used:", "Клавиша {0} уже используется:", "Клавіша {0} вже використовується:").Replace("{0}", KeyText(pend.key))
                          + "\n" + pend.holders + "\n\n"
                          + T("Are you sure you want to replace it?", "Вы уверены, что хотите заменить эту клавишу?", "Ви впевнені, що хочете замінити цю клавішу?");
            if (pend.gameConflict)
                text += "\n" + T("The game's own binding is not changed, so both will react.", "Привязка самой игры не меняется, поэтому сработают оба действия.", "Прив'язка самої гри не змінюється, тому спрацюють обидві дії.");
            GUI.Label(new Rect(m.x + 20, m.y + 46, m.width - 40, 120), text, sWrap);
            if (GUI.Button(new Rect(m.x + 20, m.yMax - 48, 240, 34), T("Yes, replace", "Да, заменить", "Так, замінити"), sBtnAccent)) ConfirmPending();
            if (GUI.Button(new Rect(m.xMax - 260, m.yMax - 48, 240, 34), T("No, cancel", "Нет, отмена", "Ні, скасувати"), sBtn)) pend = null;
        }

        // ---------- вкладки ----------
        void TabPlayer()
        {
            var mods = Master != null ? ModsFor(Master) : new PlayerMods();
            scrolls[0] = GUILayout.BeginScrollView(scrolls[0]);
            Section(T("Abilities", "Возможности", "Можливості"));
            GUILayout.BeginHorizontal();
            GUILayout.BeginVertical();
            god = Sw(god, T("God mode", "Бессмертие", "Безсмертя"));
            fly = Sw(fly, T("Fly  (Space / Ctrl / Shift)", "Полёт  (Пробел / Ctrl / Shift)", "Політ  (Пробіл / Ctrl / Shift)"));
            noclip = Sw(noclip, T("Noclip", "Ноуклип", "Ноуклип"));
            GUILayout.EndVertical();
            GUILayout.BeginVertical();
            infJumps = Sw(infJumps, T("Infinite jumps", "Бесконечные прыжки", "Нескінченні стрибки"));
            freeInteract = Sw(freeInteract, T("Free purchases", "Бесплатные покупки", "Безкоштовні покупки"));
            aimbot = Sw(aimbot, T("Aimbot", "Аимбот", "Аімбот"));
            GUILayout.EndVertical();
            GUILayout.EndHorizontal();
            flySpeed = SliderRowReset(T("Fly speed", "Скорость полёта", "Швидкість польоту"), flySpeed, 5f, 100f, "0", 20f);

            if (aimbot)
            {
                Section(T("Aimbot", "Аимбот", "Аімбот"));
                aimFov = SliderRowReset(T("Field of view", "Угол захвата", "Кут захоплення"), aimFov, 3f, 180f, "0", 25f);
                aimRange = SliderRowReset(T("Range", "Дальность", "Дальність"), aimRange, 10f, 500f, "0", 120f);
                aimSmooth = SliderRowReset(T("Smoothing", "Плавность", "Плавність"), aimSmooth, 0f, 0.95f, "0.00", 0.3f);
                aimVisible = Sw(aimVisible, T("Visible targets only", "Только видимые цели", "Лише видимі цілі"));
            }

            Section(T("Infinite charges", "Бесконечные заряды", "Нескінченні заряди"));
            GUILayout.BeginHorizontal();
            GUILayout.BeginVertical();
            ncPrimary = Sw(ncPrimary, T("Primary skill", "Основное умение", "Основне вміння"));
            ncSecondary = Sw(ncSecondary, T("Secondary skill", "Вторичное умение", "Вторинне вміння"));
            ncUtility = Sw(ncUtility, T("Utility skill", "Утилитарное умение", "Утилітарне вміння"));
            GUILayout.EndVertical();
            GUILayout.BeginVertical();
            ncSpecial = Sw(ncSpecial, T("Special skill (ultimate)", "Особое умение (ульта)", "Особливе вміння (ульта)"));
            ncEquip = Sw(ncEquip, T("Equipment", "Снаряжение", "Спорядження"));
            bool all = Sw(AllSkillsNoCd, T("All skills", "Все умения", "Усі вміння"));
            if (all != AllSkillsNoCd) AllSkillsNoCd = all;
            GUILayout.EndVertical();
            GUILayout.EndHorizontal();

            Section(T("Movement stats", "Параметры движения", "Параметри руху"));
            bool ch = false;
            float v;
            v = SliderRowReset(T("Move speed x", "Скорость бега x", "Швидкість бігу x"), speedMul, 0.5f, 10f, "0.0", 1f); ch |= v != speedMul; speedMul = v;
            v = SliderRowReset(T("Attack speed x", "Скорость атаки x", "Швидкість атаки x"), atkSpeedMul, 0.5f, 10f, "0.0", 1f); ch |= v != atkSpeedMul; atkSpeedMul = v;
            v = SliderRowReset(T("Jump power x", "Высота прыжка x", "Висота стрибка x"), jumpMul, 0.5f, 5f, "0.0", 1f); ch |= v != jumpMul; jumpMul = v;

            Section(T("Combat stats", "Боевые параметры", "Бойові параметри"));
            v = SliderRowReset(T("Armor +", "Броня +", "Броня +"), mods.armor, -100f, 1000f, "0", 0f); ch |= v != mods.armor; mods.armor = v;
            v = SliderRowReset(T("Crit chance +%", "Шанс крита +%", "Шанс крита +%"), mods.critChance, 0f, 100f, "0", 0f); ch |= v != mods.critChance; mods.critChance = v;
            v = SliderRowReset(T("Crit damage x", "Урон крита x", "Шкода крита x"), mods.critDmg, 1f, 20f, "0.0", 1f); mods.critDmg = v;
            if (ch) ApplyAll();

            Section(T("Money and experience", "Деньги и опыт", "Гроші та досвід"));
            GUILayout.BeginHorizontal();
            GUILayout.Label(T("Gold", "Золото", "Золото"), sDim, GUILayout.Width(70));
            moneyStr = GUILayout.TextField(moneyStr, sField, GUILayout.Width(110), GUILayout.Height(28));
            uint amt;
            if (BtnA(T("Add", "Добавить", "Додати"), GUILayout.Width(130)) && uint.TryParse(moneyStr, out amt)) GiveMoney(amt);
            if (Btn("+$1k", GUILayout.Width(64))) GiveMoney(1000);
            if (Btn("+$100k", GUILayout.Width(64))) GiveMoney(100000);
            if (Btn("+$10M", GUILayout.Width(64))) GiveMoney(10000000);
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            GUILayout.Label(T("Lunar coins", "Лунные монеты", "Місячні монети"), sDim, GUILayout.Width(110));
            if (Btn("+10", GUILayout.Width(64))) GiveLunar(10);
            if (Btn("+100", GUILayout.Width(64))) GiveLunar(100);
            if (Btn("+1000", GUILayout.Width(64))) GiveLunar(1000);
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            GUILayout.Label(T("Levels", "Уровни", "Рівні"), sDim, GUILayout.Width(110));
            if (Btn("+1", GUILayout.Width(64))) GiveLevels(1);
            if (Btn("+5", GUILayout.Width(64))) GiveLevels(5);
            if (Btn("+10", GUILayout.Width(64))) GiveLevels(10);
            if (Btn("+50", GUILayout.Width(64))) GiveLevels(50);
            GUILayout.EndHorizontal();

            Section(T("Health and inventory", "Здоровье и инвентарь", "Здоров'я та інвентар"));
            GUILayout.BeginHorizontal();
            if (Btn(T("Full heal", "Полное лечение", "Повне лікування"), GUILayout.Width(220))) HealFull();
            if (Btn(T("Clear inventory", "Очистить инвентарь", "Очистити інвентар"), GUILayout.Width(220)))
            { var b = Body; if (b != null) ClearInventory(b.inventory); }
            GUILayout.EndHorizontal();
            GUILayout.EndScrollView();
        }

        static readonly Color[] tierColors =
        {
            new Color(0.88f, 0.88f, 0.88f), new Color(0.45f, 0.85f, 0.45f), new Color(0.95f, 0.35f, 0.35f),
            new Color(0.95f, 0.85f, 0.30f), new Color(0.45f, 0.70f, 1.00f), new Color(0.78f, 0.48f, 0.95f), new Color(0.60f, 0.62f, 0.68f)
        };

        string[] TierNames()
        {
            return new string[]
            {
                T("Common", "Обычные", "Звичайні"), T("Uncommon", "Необычные", "Незвичайні"), T("Legendary", "Легендарные", "Легендарні"),
                T("Boss", "Боссов", "Босів"), T("Lunar", "Лунные", "Місячні"), T("Void", "Пустоты", "Порожнечі"), T("Other", "Прочие", "Інші")
            };
        }

        void TabItems()
        {
            var b = Body;
            ItemsView(b != null ? b.inventory : null, ref itemSearch, 1);
        }

        // Список предметов для любого инвентаря (свой или выбранного игрока)
        void ItemsView(Inventory inv, ref string search, int slot)
        {
            if (items == null) { Dim(T("Catalog is loading...", "Каталог загружается...", "Каталог завантажується...")); return; }
            CountRow();
            search = SearchField(search);

            GUILayout.BeginHorizontal();
            string[] tn = TierNames();
            var oc = GUI.contentColor;
            for (int i = 0; i < 7; i++)
            {
                bool on = (tierMask & (1 << i)) != 0;
                GUI.contentColor = tierColors[i];
                bool nv = GUILayout.Toggle(on, tn[i], sChip, GUILayout.Height(28));
                if (nv != on) tierMask ^= 1 << i;
            }
            GUI.contentColor = oc;
            ownedOnly = GUILayout.Toggle(ownedOnly, T("Owned", "Есть у меня", "Наявні"), sChip, GUILayout.Height(28));
            GUILayout.FlexibleSpace();
            if (Btn(T("Remove all", "Убрать все", "Прибрати всі"), GUILayout.Width(130), GUILayout.Height(28))) RemoveAllItems(inv);
            GUILayout.EndHorizontal();

            var list = Filter(items, search).Where(e => (tierMask & (1 << e.group)) != 0).ToList();
            if (ownedOnly && inv != null)
                list = list.Where(e => inv.GetItemCountPermanent(((ItemDef)e.data).itemIndex) > 0).ToList();
            list = WithHeaders(list, e => e.group, g => tn[g]);

            ListView(slot, list, 44f, delegate(Entry e, Rect r)
            {
                int have = inv != null ? inv.GetItemCountPermanent(((ItemDef)e.data).itemIndex) : 0;
                string lw = ExpansionLock(e);
                RowHead(e, r, lw ?? tn[e.group], lw != null, false);
                float x = r.xMax - 262;
                if (lw != null && have == 0) { GUI.Button(new Rect(x + 70, r.y + (r.height - 28f) / 2f, 192, 28), T("Locked", "Недоступно", "Недоступно"), sBtnOff); return; }
                GUI.Label(new Rect(x, r.y + 8, 70, 24), "x" + have, have > 0 ? sTitle : sDim);
                if (GUI.Button(new Rect(x + 70, r.y + (r.height - 28f) / 2f, 60, 28), "-" + count, sBtn)) GiveItem(inv, e, -count);
                if (GUI.Button(new Rect(x + 134, r.y + (r.height - 28f) / 2f, 60, 28), "+" + count, sBtnAccent)) GiveItem(inv, e, count);
                if (GUI.Button(new Rect(x + 198, r.y + (r.height - 28f) / 2f, 64, 28), T("all", "все", "всі"), sBtn)) GiveItem(inv, e, -have);
            });
        }

        void TabEquipment()
        {
            var b = Body;
            EquipView(b != null ? b.inventory : null, ref equipSearch, 2);
        }

        void EquipView(Inventory inv, ref string search, int slot)
        {
            if (equips == null) { Dim(T("Catalog is loading...", "Каталог загружается...", "Каталог завантажується...")); return; }
            search = SearchField(search);
            if (Btn(T("Remove equipment", "Убрать снаряжение", "Прибрати спорядження"), GUILayout.Width(220)))
                SetEquipment(inv, EquipmentIndex.None, "-");
            var list = WithHeaders(Filter(equips, search), e => e.group, g =>
                g == 0 ? T("Equipment", "Снаряжение", "Спорядження")
                : (g == 1 ? T("Lunar equipment", "Лунное снаряжение", "Місячне спорядження")
                : T("Elite aspects and other", "Аспекты элиты и прочее", "Аспекти еліти та інше")));
            ListView(slot, list, 44f, delegate(Entry e, Rect r)
            {
                string lw = ExpansionLock(e);
                RowHead(e, r, lw ?? "", lw != null, false);
                var br = RowBtn(r);
                if (lw != null) GUI.Button(br, T("Locked", "Недоступно", "Недоступно"), sBtnOff);
                else if (GUI.Button(br, T("Equip", "Взять", "Взяти"), sBtnAccent))
                    SetEquipment(inv, ((EquipmentDef)e.data).equipmentIndex, e.name);
            });
        }

        // ---------- глобальный поиск ----------
        void TabSearch()
        {
            var list = BuildSearchResults(globalSearch);
            if (list.Count == 0) { Dim(T("Nothing found.", "Ничего не найдено.", "Нічого не знайдено.")); return; }
            CountRow();
            ListView(18, list, 46f, delegate(Entry e, Rect r)
            {
                var br = RowBtn(r);
                if (e.group == 0)
                {
                    var f = (Feat)e.data;
                    RowHead(e, r, e.sub, false, true);
                    string label = f.tab >= 0 ? T("Open", "Открыть", "Відкрити")
                        : (f.on != null ? (f.on() ? T("Turn off", "Выключить", "Вимкнути") : T("Turn on", "Включить", "Увімкнути")) : T("Run", "Выполнить", "Виконати"));
                    if (GUI.Button(br, label, sBtnAccent))
                    {
                        if (f.tab >= 0) { tab = f.tab; globalSearch = ""; }
                        else if (f.act != null) f.act();
                    }
                    return;
                }
                string lockWhy = ExpansionLock(e);
                bool off = lockWhy != null;
                RowHead(e, r, off ? lockWhy : e.sub, off, false);
                if (off) { GUI.Button(br, T("Locked", "Недоступно", "Недоступно"), sBtnOff); return; }
                var body = Body;
                switch (e.group)
                {
                    case 1:
                        if (GUI.Button(br, "+" + count, sBtnAccent)) GiveItem(body != null ? body.inventory : null, e, count);
                        break;
                    case 2:
                        if (GUI.Button(br, T("Equip", "Взять", "Взяти"), sBtnAccent)) SetEquipment(body != null ? body.inventory : null, ((EquipmentDef)e.data).equipmentIndex, e.name);
                        break;
                    case 3:
                        if (GUI.Button(br, T("Play as", "Играть", "Грати"), sBtnAccent)) SwitchCharacter(e);
                        break;
                    case 4:
                        if (GUI.Button(br, T("Summon", "Призвать", "Призвати"), sBtnAccent)) Summon(e.prefab, TeamIndex.Player, true, count, e.name);
                        break;
                    case 5:
                        if (GUI.Button(br, T("Spawn", "Создать", "Створити"), sBtnAccent))
                            Summon(e.prefab, spawnTeam == 1 ? TeamIndex.Player : TeamIndex.Monster, spawnTeam == 1, count, e.name);
                        break;
                    case 6:
                        if (GUI.Button(br, T("Go", "Перейти", "Перейти"), sBtnAccent)) GoToStage(e);
                        break;
                    case 7:
                        if (GUI.Button(br, T("Play", "Включить", "Увімкнути"), sBtnAccent)) PlayTrack(e);
                        break;
                }
            });
        }

        // ---------- игроки в мире ----------
        int selPlayer, plSub;
        string plItemSearch = "", plEquipSearch = "", plMoneyStr = "10000";

        void TabPlayers()
        {
            var all = PlayerCharacterMasterController.instances.Where(p => p != null && p.master != null).ToList();
            if (all.Count == 0) { Dim(T("No players yet.", "Игроков пока нет.", "Гравців поки немає.")); return; }
            selPlayer = Mathf.Clamp(selPlayer, 0, all.Count - 1);

            Dim(T("Changes work for the host only. Other players keep their own settings.", "Изменения работают только у хоста. Остальные игроки сохраняют свои настройки.", "Зміни працюють лише у хоста. Інші гравці зберігають свої налаштування."));
            GUILayout.BeginHorizontal();
            for (int i = 0; i < all.Count; i++)
            {
                var b0 = all[i].master.GetBody();
                string nm = PlayerName(all[i]) + (b0 != null ? "  (" + b0.GetDisplayName() + ")" : "") + (all[i].master == Master ? "  [" + T("you", "вы", "ви") + "]" : "");
                if (GUILayout.Toggle(selPlayer == i, nm, sChip, GUILayout.Height(28)) && selPlayer != i) selPlayer = i;
            }
            GUILayout.EndHorizontal();

            var pm = all[selPlayer].master;
            var body = pm.GetBody();
            var mods = ModsFor(pm);
            string[] subs = { T("Overview", "Обзор", "Огляд"), T("Items", "Предметы", "Предмети"), T("Equipment", "Снаряжение", "Спорядження"), T("Stats", "Статы", "Стати") };
            plSub = GUILayout.Toolbar(plSub, subs, sChip, GUILayout.Height(28));
            GUILayout.Space(4);

            if (plSub == 1) { ItemsView(pm.inventory, ref plItemSearch, 14); return; }
            if (plSub == 2) { EquipView(pm.inventory, ref plEquipSearch, 15); return; }

            scrolls[16] = GUILayout.BeginScrollView(scrolls[16]);
            if (plSub == 3)
            {
                bool ch = false;
                float v;
                v = SliderRowReset(T("Max health x", "Макс. здоровье x", "Макс. здоров'я x"), mods.hp, 0.1f, 20f, "0.0", 1f); ch |= v != mods.hp; mods.hp = v;
                v = SliderRowReset(T("Damage x", "Урон x", "Шкода x"), mods.dmg, 0.1f, 20f, "0.0", 1f); ch |= v != mods.dmg; mods.dmg = v;
                v = SliderRowReset(T("Move speed x", "Скорость бега x", "Швидкість бігу x"), mods.spd, 0.5f, 10f, "0.0", 1f); ch |= v != mods.spd; mods.spd = v;
                v = SliderRowReset(T("Attack speed x", "Скорость атаки x", "Швидкість атаки x"), mods.atk, 0.5f, 10f, "0.0", 1f); ch |= v != mods.atk; mods.atk = v;
                v = SliderRowReset(T("Jump power x", "Высота прыжка x", "Висота стрибка x"), mods.jump, 0.5f, 5f, "0.0", 1f); ch |= v != mods.jump; mods.jump = v;
                v = SliderRowReset(T("Armor +", "Броня +", "Броня +"), mods.armor, -100f, 1000f, "0", 0f); ch |= v != mods.armor; mods.armor = v;
                v = SliderRowReset(T("Crit chance +%", "Шанс крита +%", "Шанс крита +%"), mods.critChance, 0f, 100f, "0", 0f); ch |= v != mods.critChance; mods.critChance = v;
                mods.critDmg = SliderRowReset(T("Crit damage x", "Урон крита x", "Шкода крита x"), mods.critDmg, 1f, 20f, "0.0", 1f);
                if (Btn(T("Reset all", "Сбросить всё", "Скинути все"), GUILayout.Width(220)))
                { mods.hp = mods.dmg = mods.spd = mods.atk = mods.jump = mods.critDmg = 1f; mods.armor = 0f; mods.critChance = 0f; ch = true; }
                if (ch) ApplyAll();
                GUILayout.EndScrollView();
                return;
            }

            // обзор
            Section(PlayerName(all[selPlayer]));
            if (body != null && body.healthComponent != null)
                Dim(T("Health", "Здоровье", "Здоров'я") + ": " + body.healthComponent.health.ToString("0") + " / " + body.healthComponent.fullHealth.ToString("0")
                    + "     " + T("Level", "Уровень", "Рівень") + ": " + body.level.ToString("0")
                    + "     " + T("Gold", "Золото", "Золото") + ": " + pm.money);
            else Dim(T("Dead or no body.", "Мёртв или нет тела.", "Мертвий або немає тіла."));

            bool isMe = pm == Master;
            mods.god = Sw(mods.god, T("God mode", "Бессмертие", "Безсмертя"));
            GUILayout.BeginHorizontal();
            if (Btn(T("Full heal", "Полное лечение", "Повне лікування"), GUILayout.Width(220))) HealPlayer(pm);
            if (Btn(T("Revive", "Воскресить", "Воскресити"), GUILayout.Width(220))) RevivePlayer(pm);
            if (Btn(T("Kill", "Убить", "Вбити"), GUILayout.Width(220))) KillPlayer(pm);
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            if (Btn(T("Clear inventory", "Очистить инвентарь", "Очистити інвентар"), GUILayout.Width(220))) ClearInventory(pm.inventory);
            if (!isMe)
            {
                int pid = pm.GetInstanceID();
                bool armed = kickArmedId == pid && Time.unscaledTime < kickArmedUntil;
                if (GUILayout.Button(armed ? T("Click again to kick", "Нажмите ещё раз - кикнуть", "Натисніть ще раз - кікнути") : T("Kick from game", "Кикнуть из игры", "Кікнути з гри"),
                    armed ? sBtnAccent : sBtn, GUILayout.Width(260)))
                {
                    if (armed) { KickPlayer(all[selPlayer]); kickArmedId = 0; }
                    else { kickArmedId = pid; kickArmedUntil = Time.unscaledTime + 4f; }
                }
            }
            GUILayout.EndHorizontal();

            Section(T("Money", "Деньги", "Гроші"));
            GUILayout.BeginHorizontal();
            plMoneyStr = GUILayout.TextField(plMoneyStr, sField, GUILayout.Width(120), GUILayout.Height(28));
            uint amt;
            if (BtnA(T("Add", "Добавить", "Додати"), GUILayout.Width(130)) && uint.TryParse(plMoneyStr, out amt)) { pm.GiveMoney(amt); Say("+$" + amt); }
            if (Btn(T("Set", "Задать", "Задати"), GUILayout.Width(130)) && uint.TryParse(plMoneyStr, out amt)) { pm.money = amt; Say("$" + amt); }
            if (Btn("+$100k", GUILayout.Width(130))) pm.GiveMoney(100000);
            GUILayout.EndHorizontal();

            Section(T("Teleport", "Телепорт", "Телепорт"));
            var me = Body;
            bool wasEnabled = GUI.enabled;
            GUI.enabled = wasEnabled && !isMe && body != null && me != null;
            GUILayout.BeginHorizontal();
            if (BtnA(T("Go to player", "К игроку", "До гравця"), GUILayout.Width(220)) && body != null) TeleportMe(body.corePosition + Vector3.up, PlayerName(all[selPlayer]));
            if (Btn(T("Bring player to me", "Игрока ко мне", "Гравця до мене"), GUILayout.Width(220)) && body != null && me != null)
            { TeleportHelper.TeleportBody(body, me.corePosition + Vector3.up); Say(T("Brought: ", "Перенесён: ", "Перенесено: ") + PlayerName(all[selPlayer])); }
            GUILayout.EndHorizontal();
            GUI.enabled = wasEnabled;
            GUILayout.EndScrollView();
        }

        void TabCharacter()
        {
            if (survivors == null) { Dim(T("Catalog is loading...", "Каталог загружается...", "Каталог завантажується...")); return; }
            showAllBodies = Sw(showAllBodies, T("Show all bodies (monsters, bosses...)", "Показать все тела (монстры, боссы...)", "Показати всі тіла (монстри, боси...)"));
            charSearch = SearchField(charSearch);
            Dim(T("Your position and items are kept. Characters from a DLC you do not own (or that is off in this run) are grayed out.",
                  "Позиция и предметы сохраняются. Персонажи из DLC, которого нет у вас (или оно выключено в этом забеге), показаны серым.",
                  "Позиція та предмети зберігаються. Персонажі з DLC, якого у вас немає (або воно вимкнено в цьому забігу), показані сірим."));
            var src = showAllBodies ? allBodies : survivors;
            RefreshLocks(src);
            var filtered = Filter(src, charSearch);
            var ok = filtered.Where(e => e.lockWhy == null).ToList();
            var locked = filtered.Where(e => e.lockWhy != null).ToList();
            var list = new List<Entry>(ok);
            if (locked.Count > 0)
            {
                var h = new Entry();
                h.header = true;
                h.name = T("Unavailable (DLC)", "Недоступны (DLC)", "Недоступні (DLC)");
                h.color = cOff;
                list.Add(h);
                list.AddRange(locked);
            }
            ListView(3, list, 48f, delegate(Entry e, Rect r)
            {
                bool off = e.lockWhy != null;
                RowHead(e, r, off ? e.lockWhy : (e.prefab != null ? e.prefab.name : ""), off, false);
                var br = RowBtn(r);
                if (off) GUI.Button(br, T("Locked", "Недоступно", "Недоступно"), sBtnOff);
                else if (GUI.Button(br, T("Play as", "Играть", "Грати"), sBtnAccent)) SwitchCharacter(e);
            });
        }

        void TabTeleport()
        {
            // основной портал - телепортер, вызывающий босса
            if (FindTeleporter() != null)
            {
                if (BtnA(T("To teleporter (boss portal)", "К телепортеру (портал босса)", "До телепорта (портал боса)"), GUILayout.Width(340), GUILayout.Height(28))) TeleportToTeleporter();
            }
            else GUILayout.Button(T("Teleporter not found on this stage", "Телепортер на этой локации не найден", "Телепорт на цій локації не знайдено"), sBtnOff, GUILayout.Width(340), GUILayout.Height(28));
            GUILayout.Space(2);
            string[] subs = { T("Stages", "Локации", "Локації"), T("Allies", "Союзники", "Союзники"), T("Objects", "Объекты", "Об'єкти"), T("Portals", "Порталы", "Портали") };
            tpSub = GUILayout.Toolbar(tpSub, subs, sChip, GUILayout.Height(28));
            GUILayout.Space(4);
            if (tpSub == 3)
            {
                var plist = new List<Entry>();
                foreach (var p in portals)
                {
                    if (p.go == null) continue;
                    var pe = new Entry();
                    pe.name = p.name;
                    pe.sub = p.dist.ToString("0") + " m";
                    pe.data = p;
                    plist.Add(pe);
                }
                if (plist.Count == 0) { Dim(T("No portals on this stage yet (they appear after the teleporter event or in special places).", "Порталов на этой локации пока нет (они появляются после события у телепортера или в особых местах).", "Порталів на цій локації поки немає (вони з'являються після події біля телепорта або в особливих місцях).")); return; }
                if (BtnA(T("To nearest portal", "К ближайшему порталу", "До найближчого порталу"), GUILayout.Width(220), GUILayout.Height(28))) TeleportToPortal((PortalInfo)plist[0].data);
                ListView(17, plist, 48f, delegate(Entry e, Rect r)
                {
                    RowHead(e, r, e.sub, false, true);
                    if (GUI.Button(RowBtn(r), T("Teleport", "Телепорт", "Телепорт"), sBtnAccent)) TeleportToPortal((PortalInfo)e.data);
                });
                return;
            }
            if (tpSub == 0)
            {
                if (scenes == null) { Dim(T("Catalog is loading...", "Каталог загружается...", "Каталог завантажується...")); return; }
                sceneSearch = SearchField(sceneSearch);
                var list = Filter(scenes, sceneSearch);
                ListView(4, list, 48f, delegate(Entry e, Rect r)
                {
                    RowHead(e, r, e.sub);
                    if (GUI.Button(RowBtn(r), T("Go", "Перейти", "Перейти"), sBtnAccent)) GoToStage(e);
                });
            }
            else if (tpSub == 1)
            {
                var me = Body;
                var list = new List<Entry>();
                foreach (var tc in TeamComponent.GetTeamMembers(TeamIndex.Player))
                {
                    if (tc == null || tc.body == null || tc.body == me) continue;
                    var e = new Entry();
                    e.name = tc.body.GetDisplayName();
                    string user = tc.body.GetUserName();
                    e.sub = string.IsNullOrEmpty(user) ? "" : user;
                    if (tc.body.portraitIcon != null) e.tex = tc.body.portraitIcon;
                    e.data = tc.body;
                    list.Add(e);
                }
                if (list.Count == 0) { Dim(T("No allies right now.", "Союзников сейчас нет.", "Союзників зараз немає.")); return; }
                ListView(5, list, 48f, delegate(Entry e, Rect r)
                {
                    RowHead(e, r, e.sub);
                    var ab = (CharacterBody)e.data;
                    if (ab == null) return;
                    if (GUI.Button(RowBtnAt(r, 1), T("Go to", "К нему", "До нього"), sBtnAccent)) TeleportMe(ab.corePosition + Vector3.up, e.name);
                    if (GUI.Button(RowBtnAt(r, 0), T("Bring", "К себе", "До себе"), sBtn) && me != null)
                    { TeleportHelper.TeleportBody(ab, me.corePosition + Vector3.up); Say(T("Brought: ", "Перенесён: ", "Перенесено: ") + e.name); }
                });
            }
            else
            {
                var list = new List<Entry>();
                foreach (var s in scan)
                {
                    if (s.go == null) continue;
                    list.Add(ScanEntry(s, s.group >= 0));
                }
                if (list.Count == 0) { Dim(T("Nothing found.", "Ничего не найдено.", "Нічого не знайдено.")); return; }
                ListView(6, list, 48f, delegate(Entry e, Rect r)
                {
                    RowHead(e, r, e.sub);
                    var s = (ScanItem)e.data;
                    if (GUI.Button(RowBtn(r), T("Teleport", "Телепорт", "Телепорт"), sBtnAccent) && s.go != null)
                        TeleportMe(s.go.transform.position + Vector3.up * 1.5f, s.name);
                });
            }
        }

        void TabDrones()
        {
            if (drones == null) { Dim(T("Catalog is loading...", "Каталог загружается...", "Каталог завантажується...")); return; }
            CountRow();
            droneSearch = SearchField(droneSearch);
            Dim(T("Drones appear at the point you are aiming at and follow you.", "Дроны появляются там, куда вы целитесь, и следуют за вами.", "Дрони з'являються там, куди ви цілитесь, і йдуть за вами."));
            var list = WithHeaders(Filter(drones, droneSearch), e => e.group, g =>
                g == 0 ? T("Common drones (gray)", "Обычные дроны (серые)", "Звичайні дрони (сірі)")
                : (g == 1 ? T("Uncommon drones (green)", "Необычные дроны (зелёные)", "Незвичайні дрони (зелені)")
                : (g == 2 ? T("Legendary drones (red)", "Легендарные дроны (красные)", "Легендарні дрони (червоні)")
                : T("Other drones", "Прочие дроны", "Інші дрони"))));
            ListView(7, list, 48f, delegate(Entry e, Rect r)
            {
                string lw = ExpansionLock(e);
                RowHead(e, r, lw ?? "", lw != null, false);
                var br = RowBtn(r);
                if (lw != null) GUI.Button(br, T("Locked", "Недоступно", "Недоступно"), sBtnOff);
                else if (GUI.Button(br, T("Summon", "Призвать", "Призвати"), sBtnAccent))
                    Summon(e.prefab, TeamIndex.Player, true, count, e.name);
            });
        }

        void TabSpawn()
        {
            if (enemies == null) { Dim(T("Catalog is loading...", "Каталог загружается...", "Каталог завантажується...")); return; }
            CountRow();
            GUILayout.BeginHorizontal();
            GUILayout.Label(T("Team", "Команда", "Команда"), sDim, GUILayout.Width(80));
            if (GUILayout.Toggle(spawnTeam == 2, T("Enemies", "Враги", "Вороги"), sChip, GUILayout.Width(130), GUILayout.Height(28))) spawnTeam = 2;
            if (GUILayout.Toggle(spawnTeam == 1, T("Allies", "Союзники", "Союзники"), sChip, GUILayout.Width(130), GUILayout.Height(28))) spawnTeam = 1;
            GUILayout.EndHorizontal();
            enemySearch = SearchField(enemySearch);
            var list = Filter(enemies, enemySearch);
            ListView(8, list, 48f, delegate(Entry e, Rect r)
            {
                RowHead(e, r, e.sub);
                if (GUI.Button(RowBtn(r), T("Spawn", "Создать", "Створити"), sBtnAccent))
                    Summon(e.prefab, spawnTeam == 1 ? TeamIndex.Player : TeamIndex.Monster, spawnTeam == 1, count, e.name);
            });
        }

        string[] CatNames()
        {
            return new string[]
            {
                T("Player", "Игрок", "Гравець"), T("Allies", "Союзники", "Союзники"),
                T("Enemies", "Враги", "Вороги"), T("Bosses", "Боссы", "Боси")
            };
        }

        void TabStats()
        {
            scrolls[9] = GUILayout.BeginScrollView(scrolls[9]);
            Dim(T("Multipliers apply to existing and newly spawned bodies (host only).",
                  "Множители применяются к текущим и новым существам (только у хоста).",
                  "Множники застосовуються до поточних і нових істот (лише у хоста)."));
            string[] cn = CatNames();
            bool ch = false;
            for (int i = 0; i < 4; i++)
            {
                Section(cn[i]);
                float v = SliderRowReset(T("Max health x", "Макс. здоровье x", "Макс. здоров'я x"), hpMul[i], 0.1f, 20f, "0.0", 1f);
                ch |= v != hpMul[i]; hpMul[i] = v;
                v = SliderRowReset(T("Damage x", "Урон x", "Шкода x"), dmgMul[i], 0.1f, 20f, "0.0", 1f);
                ch |= v != dmgMul[i]; dmgMul[i] = v;
                GUILayout.BeginHorizontal();
                GUILayout.Space(190);
                float[] presets = { 1f, 2f, 5f, 10f, 50f, 100f };
                foreach (float p in presets)
                {
                    if (GUILayout.Button("x" + p, sChip, GUILayout.Width(64), GUILayout.Height(28)))
                    { hpMul[i] = p; dmgMul[i] = p; ch = true; }
                }
                GUILayout.EndHorizontal();
            }
            GUILayout.Space(8);
            if (Btn(T("Reset all to x1", "Сбросить всё на x1", "Скинути все на x1"), GUILayout.Width(220)))
            {
                for (int i = 0; i < 4; i++) { hpMul[i] = 1f; dmgMul[i] = 1f; }
                speedMul = 1f; atkSpeedMul = 1f; jumpMul = 1f;
                ch = true;
            }
            if (ch) ApplyAll();
            GUILayout.EndScrollView();
        }

        void TabScanner()
        {
            Section(T("Highlights through walls", "Подсветка сквозь стены", "Підсвітка крізь стіни"));
            GUILayout.BeginHorizontal();
            espEnemies = Sw(espEnemies, T("Highlight enemies", "Подсветка врагов", "Підсвітка ворогів"));
            snapEnemies = GUILayout.Toggle(snapEnemies, T("Snap lines", "Линии к цели", "Лінії до цілі"), sChip, GUILayout.Height(28), GUILayout.Width(130));
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            espPlayers = Sw(espPlayers, T("Highlight players", "Подсветка игроков", "Підсвітка гравців"));
            snapPlayers = GUILayout.Toggle(snapPlayers, T("Snap lines", "Линии к цели", "Лінії до цілі"), sChip, GUILayout.Height(28), GUILayout.Width(130));
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            espOn = Sw(espOn, T("X-ray: show items through walls", "Рентген: видеть предметы сквозь стены", "Рентген: бачити предмети крізь стіни"));
            snapItems = GUILayout.Toggle(snapItems, T("Snap lines", "Линии к цели", "Лінії до цілі"), sChip, GUILayout.Height(28), GUILayout.Width(130));
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            espContents = GUILayout.Toggle(espContents, T("Chest contents", "Содержимое сундуков", "Вміст скринь"), sChip, GUILayout.Height(28));
            espPickups = GUILayout.Toggle(espPickups, T("Dropped items", "Выпавшие предметы", "Випалі предмети"), sChip, GUILayout.Height(28));
            espInteract = GUILayout.Toggle(espInteract, T("Shrines / other objects", "Алтари / прочие объекты", "Вівтарі / інші об'єкти"), sChip, GUILayout.Height(28));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            string[] tn = TierNames();
            var tcols = new Color[8];
            Array.Copy(tierColors, tcols, 7);
            tcols[7] = new Color(1f, 0.62f, 0.22f);
            var oc = GUI.contentColor;
            for (int i = 0; i < 8; i++)
            {
                bool on = (xrayMask & (1 << i)) != 0;
                GUI.contentColor = tcols[i];
                string label = i == 7 ? T("Equipment", "Снаряжение", "Спорядження") : tn[i];
                if (GUILayout.Toggle(on, label, sChip, GUILayout.Height(28)) != on) xrayMask ^= 1 << i;
            }
            GUI.contentColor = oc;
            GUILayout.EndHorizontal();

            espRange = SliderRow(T("Max distance", "Макс. дистанция", "Макс. дистанція"), espRange, 20f, 1000f, "0");
            scanSearch = SearchField(scanSearch);
            espFilter = scanSearch.Trim().ToLowerInvariant();

            var list = new List<Entry>();
            foreach (var s in scan)
            {
                bool asContent;
                if (s.go == null || !ScanVisible(s, out asContent)) continue;
                string hay = (s.name + " " + s.content).ToLowerInvariant();
                if (espFilter.Length > 0 && hay.IndexOf(espFilter, StringComparison.Ordinal) < 0) continue;
                list.Add(ScanEntry(s, asContent));
            }
            Dim(T("Found: ", "Найдено: ", "Знайдено: ") + list.Count);
            ListView(10, list, 46f, delegate(Entry e, Rect r)
            {
                RowHead(e, r, e.sub);
                var s = (ScanItem)e.data;
                if (GUI.Button(RowBtn(r), T("Teleport", "Телепорт", "Телепорт"), sBtn) && s.go != null)
                    TeleportMe(s.go.transform.position + Vector3.up * 1.5f, s.name);
            });
        }

        void TabWorld()
        {
            scrolls[11] = GUILayout.BeginScrollView(scrolls[11]);
            Section(T("Stage", "Локация", "Локація"));
            if (Btn(T("Charge teleporter instantly", "Мгновенно зарядить телепортер", "Миттєво зарядити телепорт"), GUILayout.Width(340))) ChargeTeleporter();
            if (Btn(T("Open all chests", "Открыть все сундуки", "Відкрити всі скрині"), GUILayout.Width(340))) OpenAllChests();
            if (Btn(T("Next stage", "Следующая локация", "Наступна локація"), GUILayout.Width(340))) NextStage();

            Section(T("Enemies", "Враги", "Вороги"));
            bool ne = Sw(noEnemies, T("Disable enemy spawning", "Отключить появление врагов", "Вимкнути появу ворогів"));
            if (ne != noEnemies) { noEnemies = ne; Cmd("no_enemies"); }
            if (Btn(T("Kill all enemies", "Убить всех врагов", "Вбити всіх ворогів"), GUILayout.Width(340))) KillAllEnemies(false);
            if (Btn(T("Kill bosses only", "Убить только боссов", "Вбити лише босів"), GUILayout.Width(340))) KillAllEnemies(true);

            Section(T("Game speed", "Скорость игры", "Швидкість гри"));
            float ts = SliderRowReset(T("Time scale", "Масштаб времени", "Масштаб часу"), timeScale, 0.1f, 5f, "0.0", 1f);
            if (ts != timeScale) { timeScale = ts; Time.timeScale = ts; }
            if (Btn(T("Reset speed", "Сбросить скорость", "Скинути швидкість"), GUILayout.Width(220))) { timeScale = 1f; Time.timeScale = 1f; }
            GUILayout.EndScrollView();
        }

        void TabMusic()
        {
            if (tracks == null) { Dim(T("Catalog is loading...", "Каталог загружается...", "Каталог завантажується...")); return; }
            GUILayout.BeginHorizontal();
            GUILayout.Label(T("Now: ", "Сейчас: ", "Зараз: ") + (musicOverride != null ? musicOverride.cachedName : T("stage default", "стандартная для локации", "стандартна для локації")), sTitle);
            GUILayout.FlexibleSpace();
            if (BtnA(T("Reset to default", "Сбросить на стандартную", "Скинути на стандартну"), GUILayout.Width(220), GUILayout.Height(28))) ResetMusic();
            GUILayout.EndHorizontal();
            Dim(T("The chosen track keeps playing on every stage (including boss fights) until you reset it.",
                  "Выбранный трек играет на всех локациях (включая боссов), пока вы его не сбросите.",
                  "Обраний трек грає на всіх локаціях (включно з босами), доки ви його не скинете."));
            // громкость музыки - это настройка самой игры (та же, что в меню параметров)
            float vol = MusicVolume();
            float nv = SliderRowReset(T("Music volume", "Громкость музыки", "Гучність музики"), vol, 0f, 100f, "0", 100f);
            if (Mathf.Abs(nv - vol) > 0.01f) SetMusicVolume(nv);
            musicSearch = SearchField(musicSearch);
            var list = Filter(tracks, musicSearch);
            ListView(12, list, 44f, delegate(Entry e, Rect r)
            {
                bool cur = e.data == (object)musicOverride;
                RowHead(e, r, e.sub, false, true);
                if (e.extra.Length > 0) GUI.Label(new Rect(r.xMax - 232, r.y + 10, 80, 24), e.extra, sDim);
                var br = RowBtn(r);
                if (GUI.Button(br, cur ? T("Playing", "Играет", "Грає") : T("Play", "Включить", "Увімкнути"), cur ? sBtn : sBtnAccent)) PlayTrack(e);
            });
        }

        // ---------- настройки ----------
        Color ColorSliders(Color c)
        {
            c.r = SliderRow("R", c.r, 0f, 1f, "0.00");
            c.g = SliderRow("G", c.g, 0f, 1f, "0.00");
            c.b = SliderRow("B", c.b, 0f, 1f, "0.00");
            return c;
        }

        void ChipGrid(string[] names, int selected, int perRow, Action<int> pick)
        {
            for (int i = 0; i < names.Length; i += perRow)
            {
                GUILayout.BeginHorizontal();
                for (int j = i; j < i + perRow && j < names.Length; j++)
                {
                    if (GUILayout.Toggle(selected == j, names[j], sChip, GUILayout.Height(28), GUILayout.MinWidth(110)) && selected != j) pick(j);
                }
                GUILayout.EndHorizontal();
            }
        }

        void TabSettings()
        {
            scrolls[13] = GUILayout.BeginScrollView(scrolls[13]);

            Section(T("Language", "Язык", "Мова"));
            ChipGrid(LangNames, lang, 4, SetLanguage);
            Dim(T("Item, character and stage names follow the game's own language.",
                  "Названия предметов, персонажей и локаций берутся из языка самой игры.",
                  "Назви предметів, персонажів і локацій беруться з мови самої гри."));
            if (cfgLang.Value == "auto")
                Dim(T("Following the game's language until you pick one here.", "Сейчас язык меню совпадает с языком игры, пока вы не выберете свой.", "Зараз мова меню збігається з мовою гри, доки ви не оберете свою."));

            Section(T("Interface", "Интерфейс", "Інтерфейс"));
            cfgScale.Value = SliderRowReset(T("Scale", "Масштаб", "Масштаб"), cfgScale.Value, 0.7f, 1.8f, "0.00", 1f);
            cfgOpacity.Value = SliderRowReset(T("Opacity", "Прозрачность фона", "Прозорість фону"), cfgOpacity.Value, 0.5f, 1f, "0.00", 0.96f);
            Dim(T("Drag the title bar to move the window, the corner to resize it.",
                  "Тяните заголовок, чтобы двигать окно, и угол, чтобы менять размер.",
                  "Тягніть заголовок, щоб рухати вікно, і кут, щоб змінювати розмір."));

            Section(T("Colors", "Цвета", "Кольори"));
            GUILayout.Label(T("Accent", "Акцент", "Акцент"), sDim);
            ChipGrid(ThemeNames(), cfgTheme.Value, 4, delegate(int i) { cfgTheme.Value = i; });
            if (cfgTheme.Value == 11)
            {
                var c = ColorSliders(FromHex(cfgAccentHex.Value, presetAccent[0]));
                cfgAccentHex.Value = ToHex(c);
            }
            else if (cfgTheme.Value == 12)
            {
                Dim(T("Gradient: color A", "Градиент: цвет A", "Градієнт: колір A"));
                cfgGradAHex.Value = ToHex(ColorSliders(FromHex(cfgGradAHex.Value, gradA[0])));
                Dim(T("Gradient: color B", "Градиент: цвет B", "Градієнт: колір B"));
                cfgGradBHex.Value = ToHex(ColorSliders(FromHex(cfgGradBHex.Value, gradB[0])));
            }
            GUILayout.Space(4);
            GUILayout.Label(T("Background", "Фон", "Тло"), sDim);
            ChipGrid(BgNames(), cfgBgTheme.Value, 4, delegate(int i) { cfgBgTheme.Value = i; });
            if (cfgBgTheme.Value == 6)
                cfgBgHex.Value = ToHex(ColorSliders(FromHex(cfgBgHex.Value, bgPreset[0])));

            Section(T("Active features overlay", "Список активных функций", "Список активних функцій"));
            cfgHud.Value = Sw(cfgHud.Value, T("Show active features on screen", "Показывать активные функции на экране", "Показувати активні функції на екрані"));
            if (cfgHud.Value)
            {
                GUILayout.Label(T("When to show", "Когда показывать", "Коли показувати"), sDim);
                ChipGrid(new string[] { T("Only while the menu is open", "Только при открытом меню", "Лише при відкритому меню"), T("Always (also when hidden)", "Всегда (и при скрытом меню)", "Завжди (і при схованому меню)") },
                    cfgHudMode.Value, 2, delegate(int i) { cfgHudMode.Value = i; });
                GUILayout.Label(T("Corner", "Угол экрана", "Кут екрана"), sDim);
                ChipGrid(new string[] { T("Top left", "Слева сверху", "Зліва вгорі"), T("Top right", "Справа сверху", "Справа вгорі"), T("Bottom left", "Слева снизу", "Зліва внизу"), T("Bottom right", "Справа снизу", "Справа внизу") },
                    cfgHudCorner.Value, 4, delegate(int i) { cfgHudCorner.Value = i; });
            }

            Section(T("Game HUD", "HUD игры", "HUD гри"));
            hideGameHud = Sw(hideGameHud, T("Hide HUD", "Скрыть HUD", "Сховати HUD"));

            Section(T("FPS counter", "Счётчик FPS", "Лічильник FPS"));
            cfgFps.Value = Sw(cfgFps.Value, T("Show FPS counter (works with the menu hidden)", "Показывать счётчик FPS (работает и при скрытом меню)", "Показувати лічильник FPS (працює і при схованому меню)"));
            string[] posNames =
            {
                T("Top left", "Слева сверху", "Зліва вгорі"), T("Top center", "Сверху по центру", "Вгорі по центру"), T("Top right", "Справа сверху", "Справа вгорі"),
                T("Bottom left", "Слева снизу", "Зліва внизу"), T("Bottom center", "Снизу по центру", "Внизу по центру"), T("Bottom right", "Справа снизу", "Справа внизу")
            };
            string[] typeNames = { T("Simple", "Обычный", "Звичайний"), T("Detailed", "Детальный", "Детальний") };
            if (cfgFps.Value)
            {
                GUILayout.Label(T("Type", "Вид", "Вигляд"), sDim);
                ChipGrid(typeNames, cfgFpsMode.Value, 2, delegate(int i) { cfgFpsMode.Value = i; });
                GUILayout.Label(T("Position", "Расположение", "Розташування"), sDim);
                ChipGrid(posNames, cfgFpsPos.Value, 3, delegate(int i) { cfgFpsPos.Value = i; });
            }

            Section(T("Ping counter", "Счётчик пинга", "Лічильник пінгу"));
            cfgPing.Value = Sw(cfgPing.Value, T("Show ping counter (works with the menu hidden)", "Показывать счётчик пинга (работает и при скрытом меню)", "Показувати лічильник пінгу (працює і при схованому меню)"));
            if (cfgPing.Value)
            {
                GUILayout.Label(T("Type", "Вид", "Вигляд"), sDim);
                ChipGrid(typeNames, cfgPingMode.Value, 2, delegate(int i) { cfgPingMode.Value = i; });
                GUILayout.Label(T("Position", "Расположение", "Розташування"), sDim);
                ChipGrid(posNames, cfgPingPos.Value, 3, delegate(int i) { cfgPingPos.Value = i; });
            }

            if (cfgFps.Value || cfgPing.Value)
            {
                Section(T("Counters look (FPS and ping)", "Вид счётчиков (FPS и пинг)", "Вигляд лічильників (FPS і пінг)"));
                GUILayout.Label(T("Color", "Цвет", "Колір"), sDim);
                ChipGrid(new string[] { T("Green", "Зелёный", "Зелений"), T("Same as menu", "Как у меню", "Як у меню"), T("Custom", "Свой", "Свій") },
                    cfgFpsColorMode.Value, 3, delegate(int i) { cfgFpsColorMode.Value = i; });
                if (cfgFpsColorMode.Value == 2)
                    cfgFpsHex.Value = ToHex(ColorSliders(FromHex(cfgFpsHex.Value, fpsGreen)));
                cfgFpsOutline.Value = Sw(cfgFpsOutline.Value, T("Outline", "Контур", "Контур"));
                cfgFpsSize.Value = (int)SliderRowReset(T("Size", "Размер", "Розмір"), cfgFpsSize.Value, 10f, 60f, "0", 18f);
            }

            Section(T("Hotkeys", "Горячие клавиши", "Гарячі клавіші"));
            Dim(T("Click a key box, then press the new key (Esc - cancel, right click - clear). Each action has a main and an extra key.",
                  "Нажмите на поле клавиши и затем на новую клавишу (Esc - отмена, правая кнопка - очистить). У каждого действия есть основная и дополнительная клавиша.",
                  "Натисніть на поле клавіші, потім на нову клавішу (Esc - скасувати, права кнопка - очистити). У кожної дії є основна та додаткова клавіша."));
            GUILayout.BeginHorizontal();
            GUILayout.Label("", sDim, GUILayout.Width(230));
            GUILayout.Label(T("Main", "Основная", "Основна"), sDim, GUILayout.Width(140));
            GUILayout.Label(T("Extra", "Дополнительная", "Додаткова"), sDim, GUILayout.Width(140));
            GUILayout.EndHorizontal();
            for (int i = 0; i < binds.Count; i++)
            {
                var b = binds[i];
                GUILayout.BeginHorizontal();
                GUILayout.Label(BindName(b), sLabel, GUILayout.Width(230), GUILayout.Height(28));
                for (int s = 0; s < 2; s++)
                {
                    bool waiting = bwAction == i && bwSlot == s;
                    string label = waiting ? "..." : KeyText(b.Get(s));
                    if (GUILayout.Button(label, waiting ? sBtnAccent : sBtn, GUILayout.Width(130), GUILayout.Height(28)))
                    { bwAction = i; bwSlot = s; }
                    var rect = GUILayoutUtility.GetLastRect();
                    var ev = Event.current;
                    if (ev.type == EventType.MouseDown && ev.button == 1 && rect.Contains(ev.mousePosition))
                    { b.Set(s, KeyCode.None); ev.Use(); }
                }
                if (GUILayout.Button(T("Reset", "Сброс", "Скинути"), sChip, GUILayout.Width(130), GUILayout.Height(28))) ResetBind(i);
                GUILayout.EndHorizontal();
            }
            if (Btn(T("Reset all hotkeys", "Сбросить все клавиши", "Скинути всі клавіші"), GUILayout.Width(220))) ResetAllBinds();

            GUILayout.Space(16);
            GUILayout.Label("Omni Mod Menu  -  " + T("Version", "Версия", "Версія") + " 1.0.0", sDim);
            GUILayout.EndScrollView();
        }

        // ---------- счётчик FPS ----------
        static readonly Color fpsGreen = new Color(0.2f, 1f, 0.35f);
        GUIStyle sFps;

        static string JoinLines(string a, string b) { return string.IsNullOrEmpty(a) ? b : a + "\n" + b; }

        // Счётчики FPS и пинга. Оба используют общие цвет, контур и размер; если положение совпадает, блоки объединяются.
        void DrawStats()
        {
            if (Event.current.type != EventType.Repaint) return;
            if (sFps == null)
            {
                sFps = new GUIStyle(sLabel);
                sFps.fontStyle = FontStyle.Bold;
                sFps.clipping = TextClipping.Overflow;
                sFps.wordWrap = false;
            }
            sFps.fontSize = Mathf.Clamp(cfgFpsSize.Value, 8, 80);

            var blocks = new string[6];
            if (cfgFps.Value)
            {
                string text = "FPS " + fpsCur.ToString("0");
                if (cfgFpsMode.Value == 1)
                {
                    text += "\n" + T("Frame time", "Время кадра", "Час кадру") + " " + frameMs.ToString("0.0") + " ms"
                          + "\n" + T("Avg", "Средн.", "Серед.") + " " + fpsAvg.ToString("0") + "   Min " + fpsMin.ToString("0") + "   Max " + fpsMax.ToString("0")
                          + "\n" + T("1% low", "1% худшие", "1% найгірші") + " " + fpsLow1.ToString("0");
                }
                int p = Mathf.Clamp(cfgFpsPos.Value, 0, 5);
                blocks[p] = JoinLines(blocks[p], text);
            }
            if (cfgPing.Value)
            {
                string text = "Ping " + pingCur.ToString("0") + " ms";
                if (cfgPingMode.Value == 1)
                {
                    text += "\n" + T("Avg", "Средн.", "Серед.") + " " + pingAvg.ToString("0") + "   Min " + pingMin.ToString("0") + "   Max " + pingMax.ToString("0")
                          + "\n" + T("Jitter", "Джиттер", "Джитер") + " " + pingJitter.ToString("0.0") + " ms";
                }
                int p = Mathf.Clamp(cfgPingPos.Value, 0, 5);
                blocks[p] = JoinLines(blocks[p], text);
            }

            Color col = cfgFpsColorMode.Value == 1 ? cAccentHover : (cfgFpsColorMode.Value == 2 ? FromHex(cfgFpsHex.Value, fpsGreen) : fpsGreen);
            for (int pos = 0; pos < 6; pos++)
            {
                if (string.IsNullOrEmpty(blocks[pos])) continue;
                string text = blocks[pos];
                sFps.alignment = (pos % 3 == 0) ? TextAnchor.UpperLeft : ((pos % 3 == 1) ? TextAnchor.UpperCenter : TextAnchor.UpperRight);
                var size = sFps.CalcSize(new GUIContent(text));
                const float margin = 12f;
                float x = (pos % 3 == 0) ? margin : ((pos % 3 == 1) ? (Screen.width - size.x) / 2f : Screen.width - size.x - margin);
                float y = pos < 3 ? margin : Screen.height - size.y - margin;
                var r = new Rect(x, y, size.x + 2f, size.y + 2f);

                var oc = GUI.contentColor;
                if (cfgFpsOutline.Value)
                {
                    GUI.contentColor = Color.black;
                    for (int ox = -1; ox <= 1; ox++)
                        for (int oy = -1; oy <= 1; oy++)
                            if (ox != 0 || oy != 0) GUI.Label(new Rect(r.x + ox, r.y + oy, r.width, r.height), text, sFps);
                }
                GUI.contentColor = col;
                GUI.Label(r, text, sFps);
                GUI.contentColor = oc;
            }
        }


        // ---------- список активных функций (HUD) ----------
        List<string> ActiveFeatures()
        {
            var l = new List<string>();
            if (hideGameHud) l.Add(T("Hide HUD", "Скрыть HUD", "Сховати HUD"));
            if (aimbot) l.Add(T("Aimbot", "Аимбот", "Аімбот"));
            if (espEnemies) l.Add(T("Highlight enemies", "Подсветка врагов", "Підсвітка ворогів"));
            if (espPlayers) l.Add(T("Highlight players", "Подсветка игроков", "Підсвітка гравців"));
            if (AllSkillsNoCd) l.Add(T("All skills", "Все умения", "Усі вміння") + " (" + T("Infinite charges", "Бесконечные заряды", "Нескінченні заряди") + ")");
            else
            {
                if (ncPrimary) l.Add(T("Primary skill", "Основное умение", "Основне вміння") + " (" + T("Infinite charges", "Бесконечные заряды", "Нескінченні заряди") + ")");
                if (ncSecondary) l.Add(T("Secondary skill", "Вторичное умение", "Вторинне вміння") + " (" + T("Infinite charges", "Бесконечные заряды", "Нескінченні заряди") + ")");
                if (ncUtility) l.Add(T("Utility skill", "Утилитарное умение", "Утилітарне вміння") + " (" + T("Infinite charges", "Бесконечные заряды", "Нескінченні заряди") + ")");
                if (ncSpecial) l.Add(T("Special skill (ultimate)", "Особое умение (ульта)", "Особливе вміння (ульта)") + " (" + T("Infinite charges", "Бесконечные заряды", "Нескінченні заряди") + ")");
            }
            if (ncEquip) l.Add(T("Equipment", "Снаряжение", "Спорядження") + " (" + T("Infinite charges", "Бесконечные заряды", "Нескінченні заряди") + ")");
            if (god) l.Add(T("God mode", "Бессмертие", "Безсмертя"));
            if (fly) l.Add(T("Fly", "Полёт", "Політ"));
            if (noclip) l.Add(T("Noclip", "Ноуклип", "Ноуклип"));
            if (infJumps) l.Add(T("Infinite jumps", "Бесконечные прыжки", "Нескінченні стрибки"));
            if (freeInteract) l.Add(T("Free purchases", "Бесплатные покупки", "Безкоштовні покупки"));
            if (espOn) l.Add(T("X-ray", "Рентген", "Рентген"));
            if (noEnemies) l.Add(T("Disable enemy spawning", "Отключить появление врагов", "Вимкнути появу ворогів"));
            if (speedMul != 1f) l.Add(T("Move speed x", "Скорость бега x", "Швидкість бігу x") + speedMul.ToString("0.0"));
            if (atkSpeedMul != 1f) l.Add(T("Attack speed x", "Скорость атаки x", "Швидкість атаки x") + atkSpeedMul.ToString("0.0"));
            if (jumpMul != 1f) l.Add(T("Jump power x", "Высота прыжка x", "Висота стрибка x") + jumpMul.ToString("0.0"));
            for (int i = 0; i < 4; i++)
            {
                if (hpMul[i] != 1f || dmgMul[i] != 1f)
                    l.Add(CatNames()[i] + ": " + T("HP", "ХП", "ХП") + " x" + hpMul[i].ToString("0.#") + ", " + T("Damage", "Урон", "Шкода") + " x" + dmgMul[i].ToString("0.#"));
            }
            if (timeScale != 1f) l.Add(T("Time scale", "Масштаб времени", "Масштаб часу") + " x" + timeScale.ToString("0.0"));
            if (musicOverride != null) l.Add(T("Music", "Музыка", "Музика") + ": " + musicOverride.cachedName);
            return l;
        }

        void DrawHud()
        {
            var f = ActiveFeatures();
            if (f.Count == 0) return;
            const float lh = 21f;
            float w = 0f;
            foreach (var s in f) w = Mathf.Max(w, sEsp.CalcSize(new GUIContent(s)).x);
            w += 36f;
            float h = f.Count * lh + 12f;
            int c = Mathf.Clamp(cfgHudCorner.Value, 0, 3);
            float x = (c == 0 || c == 2) ? 12f : Screen.width - w - 12f;
            float y = c < 2 ? 12f : Screen.height - h - 12f;
            GUI.Box(new Rect(x, y, w, h), GUIContent.none, sEspBg);
            var oc = GUI.color;
            var occ = GUI.contentColor;
            for (int i = 0; i < f.Count; i++)
            {
                GUI.color = cAccent;
                GUI.Box(new Rect(x + 10, y + 11 + i * lh, 8, 8), GUIContent.none, sDot);
                GUI.color = oc;
                GUI.contentColor = Color.white;
                GUI.Label(new Rect(x + 26, y + 6 + i * lh, w, lh), f[i], sEsp);
            }
            GUI.contentColor = occ;
            GUI.color = oc;
        }

        // ---------- метки сканера на экране ----------
        int xrayMask = 255;

        // asContent: показываем как предмет (его иконка и цвет редкости); иначе - как обычный объект
        bool ScanVisible(ScanItem s, out bool asContent)
        {
            asContent = s.group >= 0 && (xrayMask & (1 << s.group)) != 0 && (s.kind == 1 ? espPickups : espContents);
            if (asContent) return true;
            return s.kind == 0 && espInteract;
        }

        Entry ScanEntry(ScanItem s, bool asContent)
        {
            var e = new Entry();
            e.data = s;
            string where = s.name + (s.cost.Length > 0 ? "  " + s.cost : "");
            if (asContent && s.kind == 0)
            {
                e.name = s.content;
                e.color = s.contentColor;
                e.sub = where + "  -  " + s.dist.ToString("0") + " m";
            }
            else
            {
                e.name = s.kind == 1 ? s.name : where;
                e.color = s.kind == 1 ? s.color : Color.white;
                e.sub = s.dist.ToString("0") + " m";
            }
            e.tex = s.contentTex;
            e.uv = s.contentUv;
            return e;
        }

        Camera GetCam()
        {
            var list = CameraRigController.readOnlyInstancesList;
            if (list.Count > 0 && list[0] != null && list[0].sceneCam != null) return list[0].sceneCam;
            return Camera.main;
        }

        void DrawEsp()
        {
            var cam = GetCam();
            if (cam == null) return;
            var body = Body;
            Vector3 me = body != null ? body.corePosition : cam.transform.position;
            int drawn = 0, offscreen = 0;
            var oc = GUI.contentColor;
            foreach (var s in scan)
            {
                bool asContent;
                if (s.go == null || !ScanVisible(s, out asContent)) continue;
                float d = Vector3.Distance(me, s.go.transform.position);
                if (d > espRange) continue;
                if (espFilter.Length > 0 && (s.name + " " + s.content).ToLowerInvariant().IndexOf(espFilter, StringComparison.Ordinal) < 0) continue;

                Vector3 sp = cam.WorldToScreenPoint(s.go.transform.position + Vector3.up * 1.3f);
                float x = sp.x, y = Screen.height - sp.y;
                bool behind = sp.z <= 0f;
                if (behind) { x = Screen.width - x; y = Screen.height - y; }
                bool off = behind || x < 0 || x > Screen.width || y < 0 || y > Screen.height;
                if (off)
                {
                    // за кадром показываем только предметы, прижав метку к краю экрана в их сторону
                    if (!asContent || ++offscreen > 25) continue;
                    x = Mathf.Clamp(x, 90f, Screen.width - 90f);
                    y = Mathf.Clamp(y, 50f, Screen.height - 20f);
                }

                string dist = d.ToString("0") + "m";
                string line1, line2 = null;
                Color c1;
                if (asContent && s.kind == 0)
                {
                    line1 = s.content; c1 = s.contentColor;
                    line2 = s.name + (s.cost.Length > 0 ? "  " + s.cost : "") + "  " + dist;
                }
                else if (asContent)
                {
                    line1 = s.name; c1 = s.color;
                    line2 = dist;
                }
                else
                {
                    line1 = s.name + (s.cost.Length > 0 ? "  " + s.cost : "") + "  " + dist; c1 = Color.white;
                }

                float iconW = asContent && s.contentTex != null ? 30f : 0f;
                float w = Mathf.Max(sEsp.CalcSize(new GUIContent(line1)).x, line2 != null ? sEsp.CalcSize(new GUIContent(line2)).x : 0f) + iconW + 14f;
                float h = line2 != null ? 38f : 22f;
                var r = new Rect(x - w / 2f, y - h, w, h);
                var oldC = GUI.color;
                if (off) GUI.color = new Color(1, 1, 1, 0.75f);
                if (snapItems) DrawLine(new Vector2(Screen.width / 2f, Screen.height), new Vector2(x, y), asContent ? s.contentColor : Color.white, 1.5f);
                GUI.Box(r, GUIContent.none, sEspBg);
                if (iconW > 0f)
                {
                    var tile = new Rect(r.x + 4, r.y + 4, h - 8, h - 8);
                    DrawTile(tile, s.contentColor, s.contentTex, s.contentUv);
                }
                GUI.contentColor = c1;
                GUI.Label(new Rect(r.x + 7 + iconW, r.y + 3, w, 18), line1, sEsp);
                if (line2 != null)
                {
                    GUI.contentColor = new Color(0.75f, 0.8f, 0.9f);
                    GUI.Label(new Rect(r.x + 7 + iconW, r.y + 19, w, 18), line2, sEsp);
                }
                GUI.color = oldC;
                if (++drawn >= 150) break;
            }
            GUI.contentColor = oc;
        }
    }
}
