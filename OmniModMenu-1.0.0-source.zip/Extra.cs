using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using BepInEx.Configuration;
using RoR2;
using UnityEngine;

namespace RoR2ModMenu
{
    class PortalInfo
    {
        public GameObject go;
        public string name = "";
        public float dist;
    }

    // Индивидуальные настройки игрока (поверх общих множителей на вкладке «Статы»)
    class PlayerMods
    {
        public bool god;
        public float hp = 1f, dmg = 1f, spd = 1f, atk = 1f, jump = 1f;
        public float armor, critChance;   // прибавка к броне и шансу крита
        public float critDmg = 1f;        // множитель урона критов
    }

    public partial class ModMenu
    {
        // ---------- порталы ----------
        readonly List<PortalInfo> portals = new List<PortalInfo>();

        string PortalName(SceneExitController sx)
        {
            string n = sx.gameObject.name.Replace("(Clone)", "").Trim();
            string label;
            if (n.IndexOf("Shop", StringComparison.OrdinalIgnoreCase) >= 0)
                label = T("Blue portal (Bazaar)", "Синий портал (Базар)", "Синій портал (Базар)");
            else if (n.IndexOf("Goldshores", StringComparison.OrdinalIgnoreCase) >= 0)
                label = T("Gold portal (Gilded Coast)", "Золотой портал (Золотой берег)", "Золотий портал (Золотий берег)");
            else if (n.IndexOf("MS", StringComparison.Ordinal) >= 0 || n.IndexOf("Moon", StringComparison.OrdinalIgnoreCase) >= 0)
                label = T("Celestial portal", "Небесный портал", "Небесний портал");
            else if (n.IndexOf("Void", StringComparison.OrdinalIgnoreCase) >= 0)
                label = T("Void portal", "Портал Пустоты", "Портал Порожнечі");
            else
                label = T("Portal", "Портал", "Портал") + " (" + n + ")";

            SceneDef dest = null;
            try { dest = sx.destinationScene; } catch (Exception) { }
            if (dest == null && sx.useRunNextStageScene && Run.instance != null) dest = Run.instance.nextStageScene;
            if (dest != null && !string.IsNullOrEmpty(dest.nameToken))
                label += "  ->  " + Language.GetString(dest.nameToken);
            return label;
        }

        void RefreshPortals(Vector3 me)
        {
            portals.Clear();
            foreach (var sx in UnityEngine.Object.FindObjectsOfType<SceneExitController>())
            {
                if (sx == null || !sx.gameObject.activeInHierarchy) continue;
                if (sx.GetComponent<TeleporterInteraction>() != null) continue; // сам телепортер есть в списке объектов
                var p = new PortalInfo();
                p.go = sx.gameObject;
                p.name = PortalName(sx);
                p.dist = Vector3.Distance(me, sx.transform.position);
                portals.Add(p);
            }
            portals.Sort((a, b) => a.dist.CompareTo(b.dist));
        }

        // Ставим игрока рядом с порталом (не вплотную, чтобы не сработал вход сразу).
        void TeleportToPortal(PortalInfo p)
        {
            var b = Body;
            if (b == null || p.go == null) return;
            Vector3 pos = p.go.transform.position;
            Vector3 dir = b.corePosition - pos;
            dir.y = 0f;
            if (dir.sqrMagnitude < 0.01f) dir = Vector3.forward;
            dir.Normalize();
            TeleportMe(pos + dir * 6f + Vector3.up * 2f, p.name);
        }

        // ---------- враги и этап ----------
        void KillAllEnemies(bool bossesOnly)
        {
            var me = Body;
            GameObject killer = me != null ? me.gameObject : null;
            int n = 0;
            foreach (var b in CharacterBody.readOnlyInstancesList.ToList())
            {
                if (b == null || b.teamComponent == null) continue;
                var t = b.teamComponent.teamIndex;
                if (t == TeamIndex.Player || t == TeamIndex.Neutral || t == TeamIndex.None) continue;
                var hc = b.healthComponent;
                if (hc == null || !hc.alive) continue;
                if (bossesOnly && !(b.isChampion || b.isBoss)) continue;
                hc.Suicide(killer, killer, default(DamageTypeCombo));
                n++;
            }
            Say(T("Enemies killed: ", "Убито врагов: ", "Вбито ворогів: ") + n);
        }

        void NextStage()
        {
            if (Run.instance != null && Run.instance.nextStageScene != null)
                Run.instance.AdvanceStage(Run.instance.nextStageScene);
            else
                Cmd("next_stage");
        }

        // ---------- HUD игры ----------
        bool hideGameHud, hudApplied;

        void ApplyGameHud()
        {
            if (hideGameHud == hudApplied) return;
            try
            {
                RoR2.UI.HUD.cvHudEnable.SetString(hideGameHud ? "0" : "1");
                hudApplied = hideGameHud;
            }
            catch (Exception ex)
            {
                Logger.LogWarning("hud_enable: " + ex.Message);
                hideGameHud = hudApplied;
            }
        }

        // ---------- громкость музыки (настройка самой игры) ----------
        object volMsx;

        object VolumeConVar()
        {
            if (volMsx == null)
            {
                var f = typeof(AudioManager).GetField("cvVolumeMsx", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static);
                if (f != null) volMsx = f.GetValue(null);
            }
            return volMsx;
        }

        float MusicVolume()
        {
            try
            {
                var cv = VolumeConVar();
                if (cv != null)
                {
                    string s = (string)cv.GetType().GetMethod("GetString", Type.EmptyTypes).Invoke(cv, null);
                    float v;
                    if (float.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out v)) return v;
                }
            }
            catch (Exception) { }
            return 100f;
        }

        void SetMusicVolume(float v)
        {
            try
            {
                var cv = VolumeConVar();
                if (cv != null)
                    cv.GetType().GetMethod("SetString", new Type[] { typeof(string) }).Invoke(cv, new object[] { v.ToString("0.#", CultureInfo.InvariantCulture) });
            }
            catch (Exception ex)
            {
                Logger.LogWarning("music volume: " + ex.Message);
            }
        }

        // ---------- длительность песен ----------
        // Таблица music_durations.json получена из банка Music.bnk игры (длина основного музыкального сегмента песни).
        Dictionary<string, double> durations;

        string TrackLength(MusicTrackDef d)
        {
            if (durations == null)
            {
                durations = new Dictionary<string, double>();
                try
                {
                    string f = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(Info.Location), "music_durations.json");
                    if (File.Exists(f))
                    {
                        foreach (var kv in ParseFlatJson(File.ReadAllText(f)))
                        {
                            double dv;
                            if (double.TryParse(kv.Value, NumberStyles.Float, CultureInfo.InvariantCulture, out dv)) durations[kv.Key] = dv;
                        }
                    }
                }
                catch (Exception ex) { Logger.LogWarning("music_durations.json: " + ex.Message); }
            }
            if (d == null || d.states == null) return "";
            foreach (var s in d.states)
            {
                try
                {
                    double v;
                    if (s != null && (durations.TryGetValue(s.Id.ToString(), out v) || durations.TryGetValue(s.Name ?? "", out v)))
                    {
                        int sec = (int)Math.Round(v);
                        return "~" + (sec / 60) + ":" + (sec % 60).ToString("00");
                    }
                }
                catch (Exception) { }
            }
            return "";
        }

        // ---------- счётчик FPS ----------
        ConfigEntry<bool> cfgFps, cfgFpsOutline;
        ConfigEntry<int> cfgFpsMode, cfgFpsColorMode, cfgFpsPos, cfgFpsSize;
        ConfigEntry<string> cfgFpsHex;

        readonly List<float> frameTimes = new List<float>(600);
        float fpsCur, fpsAvg, fpsMin, fpsMax, fpsLow1, frameMs, fpsNext, fpsAccum;
        int fpsFrames;

        void SampleFps()
        {
            if (!cfgFps.Value) return;
            float dt = Time.unscaledDeltaTime;
            if (dt <= 0f) return;
            if (frameTimes.Count >= 600) frameTimes.RemoveAt(0);
            frameTimes.Add(dt);
            fpsFrames++;
            fpsAccum += dt;
            if (Time.unscaledTime < fpsNext) return;
            fpsNext = Time.unscaledTime + 0.25f;
            fpsCur = fpsFrames / Mathf.Max(fpsAccum, 0.0001f);
            frameMs = fpsAccum / Mathf.Max(fpsFrames, 1) * 1000f;
            fpsFrames = 0;
            fpsAccum = 0f;
            if (cfgFpsMode.Value == 1 && frameTimes.Count > 0)
            {
                var s = frameTimes.OrderBy(x => x).ToList();
                float avg = s.Average();
                fpsAvg = 1f / avg;
                fpsMax = 1f / s[0];
                fpsMin = 1f / s[s.Count - 1];
                int idx = Mathf.Clamp((int)(s.Count * 0.99f), 0, s.Count - 1);
                fpsLow1 = 1f / s[idx];
            }
        }

        // ---------- счётчик пинга ----------
        ConfigEntry<bool> cfgPing;
        ConfigEntry<int> cfgPingMode, cfgPingPos;
        readonly List<float> pingSamples = new List<float>(240);
        float pingCur, pingAvg, pingMin, pingMax, pingJitter, pingNext;

        void SamplePing()
        {
            if (!cfgPing.Value || Time.unscaledTime < pingNext) return;
            pingNext = Time.unscaledTime + 0.25f;
            float ms = 0f;
            try
            {
                var nm = RoR2.Networking.NetworkManagerSystem.singleton;
                if (nm != null)
                {
                    float rtt = nm.filteredClientRttFrame;
                    ms = rtt > 10f ? rtt : rtt * 1000f; // значение в секундах; на случай миллисекунд
                }
            }
            catch (Exception) { }
            pingCur = ms;
            if (pingSamples.Count >= 240) pingSamples.RemoveAt(0);
            pingSamples.Add(ms);
            if (cfgPingMode.Value == 1 && pingSamples.Count > 0)
            {
                pingAvg = pingSamples.Average();
                pingMin = pingSamples.Min();
                pingMax = pingSamples.Max();
                float sum = 0f;
                foreach (var s in pingSamples) sum += (s - pingAvg) * (s - pingAvg);
                pingJitter = Mathf.Sqrt(sum / pingSamples.Count);
            }
        }

        // ---------- игроки в мире ----------
        readonly Dictionary<int, PlayerMods> pmods = new Dictionary<int, PlayerMods>();

        PlayerMods ModsFor(CharacterMaster m)
        {
            int id = m.GetInstanceID();
            PlayerMods pm;
            if (!pmods.TryGetValue(id, out pm)) { pm = new PlayerMods(); pmods[id] = pm; }
            return pm;
        }

        string PlayerName(PlayerCharacterMasterController p)
        {
            string n = "";
            try { var nu = p.networkUser; if (nu != null) n = nu.userName; } catch (Exception) { }
            if (string.IsNullOrEmpty(n)) { try { n = p.GetDisplayName(); } catch (Exception) { } }
            return string.IsNullOrEmpty(n) ? "?" : n;
        }

        // Бессмертие для остальных игроков (локальный игрок обрабатывается в Update)
        void PlayersTick()
        {
            foreach (var p in PlayerCharacterMasterController.instances)
            {
                var m = p.master;
                if (m == null || m == Master) continue;
                var b = m.GetBody();
                if (b == null || b.healthComponent == null) continue;
                var pm = ModsFor(m);
                if (pm.god || b.healthComponent.godMode) b.healthComponent.godMode = pm.god;
            }
        }

        void KillPlayer(CharacterMaster m)
        {
            var b = m.GetBody();
            if (b != null && b.healthComponent != null && b.healthComponent.alive)
                b.healthComponent.Suicide(null, null, default(DamageTypeCombo));
        }

        void RevivePlayer(CharacterMaster m)
        {
            if (m.GetBody() == null) m.RespawnExtraLife();
        }

        void HealPlayer(CharacterMaster m)
        {
            var b = m.GetBody();
            if (b != null && b.healthComponent != null) b.healthComponent.HealFraction(1f, default(ProcChainMask));
        }
    }
}
