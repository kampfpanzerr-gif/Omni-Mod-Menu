# Builds the plugin and creates release archives in release\
#   OmniModMenu-<version>-thunderstore.zip  - for Thunderstore (r2modman / Thunderstore Mod Manager)
#   OmniModMenu-<version>-manual.zip        - manual install / Nexus Mods (game folder layout)
#   OmniModMenu-<version>-source.zip        - sources
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$root    = $PSScriptRoot
$src     = Join-Path $root "release-src"
$release = Join-Path $root "release"
New-Item -ItemType Directory -Force $release | Out-Null
$manifest = Get-Content (Join-Path $src "manifest.json") -Raw -Encoding UTF8 | ConvertFrom-Json
$version = $manifest.version_number

# the manifest version must match the plugin version in code
$code = Get-Content (Join-Path $root "ModMenu.cs") -Raw -Encoding UTF8
if ($code -notmatch ('\[BepInPlugin\("[^"]+", "[^"]+", "' + [regex]::Escape($version) + '"\)\]')) { throw "manifest.json version ($version) does not match ModMenu.cs" }

# 1. build
& powershell -ExecutionPolicy Bypass -File (Join-Path $root "build.ps1") | Where-Object { $_ -notmatch "CS0618" }
$g = "D:\SteamLibrary\steamapps\common\Risk of Rain 2\BepInEx\plugins\OmniModMenu"
$dll = Join-Path $g "OmniModMenu.dll"
if (-not (Test-Path $dll)) { throw "Missing $dll - build failed" }

# 2. plugin files
$stage = Join-Path $release "_stage"
if (Test-Path $stage) { Remove-Item -Recurse -Force $stage }
New-Item -ItemType Directory -Force "$stage\plugin\lang" | Out-Null
Copy-Item $dll "$stage\plugin\"
Copy-Item (Join-Path $root "data\music_durations.json") "$stage\plugin\"
Copy-Item (Join-Path $root "lang\*.json") "$stage\plugin\lang\"

function New-Zip([string]$zipPath, [hashtable]$entries) {
    if (Test-Path $zipPath) { Remove-Item $zipPath }
    $zip = [System.IO.Compression.ZipFile]::Open($zipPath, [System.IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach ($name in ($entries.Keys | Sort-Object)) {
            [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $entries[$name], $name, [System.IO.Compression.CompressionLevel]::Optimal)
        }
    } finally { $zip.Dispose() }
}

function Files-Under([string]$dir, [string]$prefix) {
    $h = @{}
    Get-ChildItem $dir -Recurse -File | ForEach-Object {
        $rel = $_.FullName.Substring($dir.Length).TrimStart('\') -replace '\\', '/'
        $h["$prefix$rel"] = $_.FullName
    }
    return $h
}

# 3. Thunderstore: manifest/icon/README/CHANGELOG in the root, plugin files under plugins/
$ts = @{
    "manifest.json" = Join-Path $src "manifest.json"
    "icon.png"      = Join-Path $src "icon.png"
    "README.md"     = Join-Path $src "README.md"
    "CHANGELOG.md"  = Join-Path $src "CHANGELOG.md"
}
(Files-Under "$stage\plugin" "plugins/").GetEnumerator() | ForEach-Object { $ts[$_.Key] = $_.Value }
$tsZip = Join-Path $release "OmniModMenu-$version-thunderstore.zip"
New-Zip $tsZip $ts

# 4. manual install: game folder layout
$man = @{ "README.md" = Join-Path $src "README.md"; "CHANGELOG.md" = Join-Path $src "CHANGELOG.md" }
(Files-Under "$stage\plugin" "BepInEx/plugins/OmniModMenu/").GetEnumerator() | ForEach-Object { $man[$_.Key] = $_.Value }
$manZip = Join-Path $release "OmniModMenu-$version-manual.zip"
New-Zip $manZip $man

# 5. sources (no binaries or temp files)
$srcEntries = @{}
foreach ($f in "ModMenu.cs", "Ui.cs", "Loc.cs", "Binds.cs", "Extra.cs", "Extra2.cs", "build.ps1", "package.ps1") { $srcEntries[$f] = Join-Path $root $f }
(Files-Under (Join-Path $root "lang") "lang/").GetEnumerator() | ForEach-Object { $srcEntries[$_.Key] = $_.Value }
(Files-Under (Join-Path $root "langsrc") "langsrc/").GetEnumerator() | ForEach-Object { $srcEntries[$_.Key] = $_.Value }
(Files-Under (Join-Path $root "data") "data/").GetEnumerator() | ForEach-Object { $srcEntries[$_.Key] = $_.Value }
(Files-Under $src "release-src/").GetEnumerator() | ForEach-Object { $srcEntries[$_.Key] = $_.Value }
Get-ChildItem (Join-Path $root "tools\bnk") -Filter *.cs | ForEach-Object { $srcEntries["tools/bnk/$($_.Name)"] = $_.FullName }
$srcZip = Join-Path $release "OmniModMenu-$version-source.zip"
New-Zip $srcZip $srcEntries

Remove-Item -Recurse -Force $stage

# 6. validate the Thunderstore archive
$script:ok = $true
function Check([bool]$cond, [string]$msg) { if ($cond) { "  OK   $msg" } else { "  FAIL $msg"; $script:ok = $false } }
"Checking $tsZip"
$z = [System.IO.Compression.ZipFile]::OpenRead($tsZip)
$names = @($z.Entries | ForEach-Object { $_.FullName })
Check ($names -contains "manifest.json") "manifest.json in the root"
Check ($names -contains "icon.png") "icon.png in the root"
Check ($names -contains "README.md") "README.md in the root"
Check ($names -contains "plugins/OmniModMenu.dll") "plugins/OmniModMenu.dll"
Check (@($names | Where-Object { $_ -match '\\' }).Count -eq 0) "no backslashes in entry names"
$z.Dispose()
Add-Type -AssemblyName System.Drawing
$img = [System.Drawing.Image]::FromFile((Join-Path $src "icon.png"))
Check ($img.Width -eq 256 -and $img.Height -eq 256) ("icon is 256x256 (" + $img.Width + "x" + $img.Height + ")")
$img.Dispose()
Check ($manifest.name -match '^[A-Za-z0-9_]+$') "package name: letters, digits, underscore only"
Check ($manifest.description.Length -le 250) ("description is at most 250 chars (" + $manifest.description.Length + ")")
Check ($manifest.version_number -match '^\d+\.\d+\.\d+$') "version looks like X.Y.Z"
Check ($manifest.dependencies.Count -ge 1) "dependencies are listed"

"`nArchives:"
Get-ChildItem $release -Filter *.zip | ForEach-Object { "{0}  {1:N0} KB  SHA256 {2}" -f $_.Name, ($_.Length / 1KB), (Get-FileHash $_.FullName -Algorithm SHA256).Hash }
if (-not $script:ok) { throw "Validation failed" }
