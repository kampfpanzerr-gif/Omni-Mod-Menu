# Рисует иконку пакета 256x256 (требование Thunderstore): тёмный скруглённый фон и градиентное кольцо.
Add-Type -AssemblyName System.Drawing
$size = 256
$bmp = New-Object System.Drawing.Bitmap $size, $size
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
$g.Clear([System.Drawing.Color]::Transparent)

# фон: скруглённый квадрат с вертикальным градиентом
$path = New-Object System.Drawing.Drawing2D.GraphicsPath
$r = 44
$path.AddArc(0, 0, $r, $r, 180, 90)
$path.AddArc($size - $r - 1, 0, $r, $r, 270, 90)
$path.AddArc($size - $r - 1, $size - $r - 1, $r, $r, 0, 90)
$path.AddArc(0, $size - $r - 1, $r, $r, 90, 90)
$path.CloseFigure()
$bg = New-Object System.Drawing.Drawing2D.LinearGradientBrush ([System.Drawing.Point]::new(0, 0)), ([System.Drawing.Point]::new(0, $size)), ([System.Drawing.Color]::FromArgb(255, 20, 26, 44)), ([System.Drawing.Color]::FromArgb(255, 9, 11, 20))
$g.FillPath($bg, $path)

# кольцо с градиентом (синий -> розовый)
$ringBrush = New-Object System.Drawing.Drawing2D.LinearGradientBrush ([System.Drawing.Point]::new(40, 40)), ([System.Drawing.Point]::new(216, 200)), ([System.Drawing.Color]::FromArgb(255, 56, 160, 242)), ([System.Drawing.Color]::FromArgb(255, 232, 62, 140))
$pen = New-Object System.Drawing.Pen $ringBrush, 22
$g.DrawEllipse($pen, 52, 38, 152, 152)

# внутренняя точка
$dot = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 240, 244, 255))
$g.FillEllipse($dot, 108, 94, 40, 40)

# подпись
$font = New-Object System.Drawing.Font "Segoe UI", 26, ([System.Drawing.FontStyle]::Bold), ([System.Drawing.GraphicsUnit]::Pixel)
$sf = New-Object System.Drawing.StringFormat
$sf.Alignment = [System.Drawing.StringAlignment]::Center
$g.DrawString("OMNI", $font, $dot, (New-Object System.Drawing.RectangleF 0, 202, $size, 40), $sf)

$out = Join-Path $PSScriptRoot "icon.png"
$bmp.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose(); $bmp.Dispose()
"saved $out"
