# Changelog

## 1.0.0

First public release.

- Player tools: god mode, fly, noclip, infinite jumps, free purchases, aimbot, per-ability infinite charges, speed / armor / crit stats, money, levels, heal, clear inventory
- Items, equipment and characters with game icons, rarity colors and grouping; locked DLC entries are grayed out
- Teleports: stages, teleporter (boss portal), portals, map objects, allies
- Drones and enemy / ally spawning
- Scanner: item X-ray (chest and shop contents), enemy and player ESP, snap lines
- Players tab for the host: per-player god mode, items, equipment, stats, money, teleport, kick
- World tools: instant teleporter charge, open all chests, kill enemies or bosses, next stage, game speed
- Music: track picker with song length, reset, volume
- FPS and ping counters (simple or detailed), active-features overlay, Hide HUD
- Themes, custom colors, scale and opacity, rebindable hotkeys (main and extra key) with conflict warnings
- Global search
- 12 interface languages
