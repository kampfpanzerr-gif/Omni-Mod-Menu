$g   = "D:\SteamLibrary\steamapps\common\Risk of Rain 2"
$man = "$g\Risk of Rain 2_Data\Managed"
$bep = "$g\BepInEx\core"
$out = "$g\BepInEx\plugins\OmniModMenu"
New-Item -ItemType Directory -Force $out | Out-Null

$refs = @(
  "$bep\BepInEx.dll", "$bep\0Harmony.dll",
  "$man\RoR2.dll", "$man\Assembly-CSharp.dll", "$man\netstandard.dll",
  "$man\UnityEngine.dll", "$man\UnityEngine.CoreModule.dll", "$man\UnityEngine.IMGUIModule.dll",
  "$man\UnityEngine.InputLegacyModule.dll", "$man\UnityEngine.UI.dll", "$man\UnityEngine.PhysicsModule.dll", "$man\UnityEngine.TextRenderingModule.dll",
  "$man\com.unity.multiplayer-hlapi.Runtime.dll", "$man\Unity.Addressables.dll",
  "$man\Rewired_Core.dll", "$man\HGUnityUtils.dll", "$man\KinematicCharacterController.dll", "$man\HGCSharpUtils.dll", "$man\Unity.TextMeshPro.dll", "$man\Unity.ResourceManager.dll", "$man\AK.Wwise.Unity.API.WwiseTypes.dll", "$man\AK.Wwise.Unity.API.dll", "$man\AK.Wwise.Unity.MonoBehaviour.dll"
) | Where-Object { Test-Path $_ } | ForEach-Object { "/r:`"$_`"" }

$src = Get-ChildItem "$PSScriptRoot\*.cs" | ForEach-Object { $_.FullName }
& "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe" /nologo /target:library /optimize+ /codepage:65001 "/out:$out\OmniModMenu.dll" @refs @src

# таблица длительностей песен (получена из Music.bnk игры утилитой tools\bnk\Gen.cs)
if (Test-Path "$PSScriptRoot\data\music_durations.json") {
  Copy-Item "$PSScriptRoot\data\music_durations.json" "$out\music_durations.json" -Force
}

# языковые пакеты (кроме английского, украинского и русского, которые зашиты в код)
if (Test-Path "$PSScriptRoot\lang") {
  New-Item -ItemType Directory -Force "$out\lang" | Out-Null
  Copy-Item "$PSScriptRoot\lang\*.json" "$out\lang\" -Force
}
