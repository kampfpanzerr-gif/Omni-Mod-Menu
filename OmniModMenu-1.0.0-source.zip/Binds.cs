using System;
using System.Collections.Generic;
using System.Linq;
using BepInEx.Configuration;
using RoR2;
using UnityEngine;

namespace RoR2ModMenu
{
    class BindAction
    {
        public string id, en, ru, uk;
        public ConfigEntry<KeyCode> k1, k2;
        public KeyCode d1, d2;
        public Action run;
        public KeyCode Get(int slot) { return slot == 0 ? k1.Value : k2.Value; }
        public void Set(int slot, KeyCode k) { if (slot == 0) k1.Value = k; else k2.Value = k; }
    }

    class PendingBind
    {
        public int action, slot;
        public KeyCode key;
        public string holders;   // кто уже использует клавишу
        public bool gameConflict;
    }

    public partial class ModMenu
    {
        readonly List<BindAction> binds = new List<BindAction>();
        int bwAction = -1, bwSlot;   // ждём нажатия клавиши для (действие, слот)
        PendingBind pend;            // ждём подтверждения замены

        void AddBind(string id, string en, string ru, string uk, KeyCode d1, KeyCode d2, Action run)
        {
            var b = new BindAction();
            b.id = id; b.en = en; b.ru = ru; b.uk = uk; b.d1 = d1; b.d2 = d2; b.run = run;
            b.k1 = Config.Bind("Keys", id + "_primary", d1, "Primary key for: " + en);
            b.k2 = Config.Bind("Keys", id + "_secondary", d2, "Secondary key for: " + en);
            binds.Add(b);
        }

        void InitBinds()
        {
            AddBind("menu", "Open / close menu", "Открыть / закрыть меню", "Відкрити / закрити меню", KeyCode.Insert, KeyCode.None, delegate { open = !open; });
            AddBind("god", "God mode", "Бессмертие", "Безсмертя", KeyCode.None, KeyCode.None, delegate { god = !god; });
            AddBind("fly", "Fly", "Полёт", "Політ", KeyCode.None, KeyCode.None, delegate { fly = !fly; });
            AddBind("noclip", "Noclip", "Ноуклип", "Ноуклип", KeyCode.None, KeyCode.None, delegate { noclip = !noclip; });
            AddBind("jumps", "Infinite jumps", "Бесконечные прыжки", "Нескінченні стрибки", KeyCode.None, KeyCode.None, delegate { infJumps = !infJumps; });
            AddBind("cooldown", "No skill cooldowns", "Без перезарядки умений", "Без перезарядки вмінь", KeyCode.None, KeyCode.None, delegate { AllSkillsNoCd = !AllSkillsNoCd; });
            AddBind("aimbot", "Aimbot", "Аимбот", "Аімбот", KeyCode.None, KeyCode.None, delegate { aimbot = !aimbot; });
            AddBind("free", "Free purchases", "Бесплатные покупки", "Безкоштовні покупки", KeyCode.None, KeyCode.None, delegate { freeInteract = !freeInteract; });
            AddBind("xray", "X-ray", "Рентген", "Рентген", KeyCode.None, KeyCode.None, delegate { espOn = !espOn; });
            AddBind("hud", "Active features overlay", "Список активных функций", "Список активних функцій", KeyCode.None, KeyCode.None, delegate { cfgHud.Value = !cfgHud.Value; });
            AddBind("heal", "Full heal", "Полное лечение", "Повне лікування", KeyCode.None, KeyCode.None, HealFull);
            AddBind("hidehud", "Hide HUD", "Скрыть HUD", "Сховати HUD", KeyCode.None, KeyCode.None, delegate { hideGameHud = !hideGameHud; });
            AddBind("fps", "FPS counter", "Счётчик FPS", "Лічильник FPS", KeyCode.None, KeyCode.None, delegate { cfgFps.Value = !cfgFps.Value; });
            AddBind("ping", "Ping counter", "Счётчик пинга", "Лічильник пінгу", KeyCode.None, KeyCode.None, delegate { cfgPing.Value = !cfgPing.Value; });
        }

        static string KeyText(KeyCode k)
        {
            return k == KeyCode.None ? "-" : k.ToString();
        }

        static bool Down(KeyCode k)
        {
            return k != KeyCode.None && Input.GetKeyDown(k);
        }

        void ProcessHotkeys()
        {
            if (bwAction >= 0 || pend != null) return;
            // пока в меню печатают в поле ввода, горячие клавиши (кроме открытия меню) отключены
            bool typing = open && GUIUtility.keyboardControl != 0;
            for (int i = 0; i < binds.Count; i++)
            {
                var b = binds[i];
                if (typing && b.id != "menu") continue;
                if (Down(b.k1.Value) || Down(b.k2.Value)) b.run();
            }
        }

        string BindName(BindAction b) { return T(b.en, b.ru, b.uk); }

        // ---------- клавиши самой игры (Rewired) ----------
        Dictionary<KeyCode, List<string>> gameKeys = new Dictionary<KeyCode, List<string>>();
        float gameKeysAt = -100f;

        void RefreshGameKeys()
        {
            if (Time.unscaledTime < gameKeysAt + 3f) return;
            gameKeysAt = Time.unscaledTime;
            var res = new Dictionary<KeyCode, List<string>>();
            try
            {
                var lu = LocalUserManager.GetFirstLocalUser();
                if (lu != null && lu.inputPlayer != null)
                {
                    foreach (Rewired.ControllerMap map in lu.inputPlayer.controllers.maps.GetMaps(Rewired.ControllerType.Keyboard, 0))
                    {
                        foreach (Rewired.ActionElementMap am in map.AllMaps)
                        {
                            if (am.keyCode == KeyCode.None) continue;
                            var a = Rewired.ReInput.mapping.GetAction(am.actionId);
                            string n = a == null ? "?" : (string.IsNullOrEmpty(a.descriptiveName) ? a.name : a.descriptiveName);
                            List<string> l;
                            if (!res.TryGetValue(am.keyCode, out l)) { l = new List<string>(); res[am.keyCode] = l; }
                            if (!l.Contains(n)) l.Add(n);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogWarning("Reading game key bindings failed: " + ex.Message);
            }
            gameKeys = res;
        }

        // Все, кто сейчас использует клавишу, кроме самого целевого слота.
        string Holders(KeyCode key, int skipAction, int skipSlot, out bool game)
        {
            RefreshGameKeys();
            var parts = new List<string>();
            List<string> g;
            game = gameKeys.TryGetValue(key, out g);
            if (game)
                parts.Add(T("Game", "Игра", "Гра") + ": " + string.Join(", ", g.ToArray()));
            for (int i = 0; i < binds.Count; i++)
            {
                for (int s = 0; s < 2; s++)
                {
                    if (i == skipAction && s == skipSlot) continue;
                    if (binds[i].Get(s) == key) parts.Add(T("Mod", "Мод", "Мод") + ": " + BindName(binds[i]));
                }
            }
            return string.Join("; ", parts.ToArray());
        }

        void HandleBindCapture()
        {
            var e = Event.current;
            if (bwAction < 0 || e.type != EventType.KeyDown || e.keyCode == KeyCode.None) return;
            e.Use();
            int a = bwAction, s = bwSlot;
            bwAction = -1;
            if (e.keyCode == KeyCode.Escape) return;

            bool game;
            string holders = Holders(e.keyCode, a, s, out game);
            if (holders.Length == 0)
            {
                binds[a].Set(s, e.keyCode);
                return;
            }
            var p = new PendingBind();
            p.action = a; p.slot = s; p.key = e.keyCode; p.holders = holders; p.gameConflict = game;
            pend = p;
        }

        void ConfirmPending()
        {
            if (pend == null) return;
            // у других действий мода клавишу забираем; у действий игры её привязка остаётся как есть
            for (int i = 0; i < binds.Count; i++)
                for (int s = 0; s < 2; s++)
                    if (!(i == pend.action && s == pend.slot) && binds[i].Get(s) == pend.key)
                        binds[i].Set(s, KeyCode.None);
            binds[pend.action].Set(pend.slot, pend.key);
            pend = null;
        }

        void ResetBind(int i)
        {
            binds[i].k1.Value = binds[i].d1;
            binds[i].k2.Value = binds[i].d2;
        }

        void ResetAllBinds()
        {
            for (int i = 0; i < binds.Count; i++) ResetBind(i);
        }
    }
}
