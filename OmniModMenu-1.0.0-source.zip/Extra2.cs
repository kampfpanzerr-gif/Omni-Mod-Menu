using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using RoR2;
using UnityEngine;

namespace RoR2ModMenu
{
    public partial class ModMenu
    {
        static ModMenu I;
        Harmony harmony;

        // ---------- Harmony: бонус к урону критов ----------
        void InitHarmony()
        {
            I = this;
            try
            {
                harmony = new Harmony("user.omni.modmenu");
                var target = AccessTools.Method(typeof(HealthComponent), "TakeDamage");
                var pre = typeof(ModMenu).GetMethod("TakeDamagePre", BindingFlags.Static | BindingFlags.NonPublic);
                harmony.Patch(target, new HarmonyMethod(pre));
            }
            catch (Exception ex)
            {
                Logger.LogWarning("Harmony patch failed (crit damage multiplier disabled): " + ex.Message);
            }
        }

        void ShutdownHarmony()
        {
            try { if (harmony != null) harmony.UnpatchSelf(); } catch (Exception) { }
            I = null;
        }

        static void TakeDamagePre(HealthComponent __instance, DamageInfo damageInfo)
        {
            var self = I;
            if (self == null || damageInfo == null || !damageInfo.crit || damageInfo.attacker == null) return;
            var ab = damageInfo.attacker.GetComponent<CharacterBody>();
            if (ab == null || !ab.isPlayerControlled || ab.master == null) return;
            var pm = self.ModsFor(ab.master);
            if (pm.critDmg != 1f) damageInfo.damage *= pm.critDmg;
        }

        // ---------- перезарядка: отдельно по каждой способности ----------
        bool ncPrimary, ncSecondary, ncUtility, ncSpecial, ncEquip;

        bool AllSkillsNoCd
        {
            get { return ncPrimary && ncSecondary && ncUtility && ncSpecial; }
            set { ncPrimary = ncSecondary = ncUtility = ncSpecial = value; }
        }

        void TickCooldowns(CharacterBody body)
        {
            var sl = body.skillLocator;
            if (sl != null)
            {
                if (ncPrimary) Refill(sl.primary);
                if (ncSecondary) Refill(sl.secondary);
                if (ncUtility) Refill(sl.utility);
                if (ncSpecial) Refill(sl.special);
            }
            if (ncEquip && body.inventory != null) body.inventory.DeductActiveEquipmentCooldown(100f);
        }

        // ---------- ноуклип: принудительно держим отключённые коллизии ----------
        // Способности и состояния персонажа сбрасывают слои коллизий, поэтому проверяем каждый кадр и каждый физический шаг.
        void EnforceNoclip()
        {
            var body = Body;
            var motor = body != null ? body.characterMotor : null;
            if (motor == null || motor.Motor == null) return;
            if (noclip)
            {
                int cur = motor.Motor.CollidableLayers.value;
                if (cur != 0) { savedLayers = cur; motor.Motor.CollidableLayers = 0; }
                noclipApplied = true;
            }
            else if (noclipApplied)
            {
                if (motor.Motor.CollidableLayers.value == 0 && savedLayers != 0) motor.Motor.CollidableLayers = savedLayers;
                noclipApplied = false;
            }
        }

        void FixedUpdate() { EnforceNoclip(); }
        void LateUpdate() { EnforceNoclip(); }

        // ---------- инвентарь ----------
        void ClearInventory(Inventory inv)
        {
            if (inv == null) return;
            RemoveAllItems(inv);
            inv.SetEquipmentIndex(EquipmentIndex.None);
            Say(T("Inventory cleared", "Инвентарь очищен", "Інвентар очищено"));
        }

        // Предмет/снаряжение/дрон из DLC, выключенного в этом забеге, игра не принимает.
        string ExpansionLock(Entry e)
        {
            var run = Run.instance;
            if (run == null || e == null || e.data == null) return null;
            try
            {
                var id = e.data as ItemDef;
                if (id != null && run.IsItemExpansionLocked(id.itemIndex)) return T("DLC disabled in this run", "DLC выключено в этом забеге", "DLC вимкнено в цьому забігу");
                var ed = e.data as EquipmentDef;
                if (ed != null && run.IsEquipmentExpansionLocked(ed.equipmentIndex)) return T("DLC disabled in this run", "DLC выключено в этом забеге", "DLC вимкнено в цьому забігу");
                var dd = e.data as DroneDef;
                if (dd != null && run.IsDroneExpansionLocked(dd.droneIndex)) return T("DLC disabled in this run", "DLC выключено в этом забеге", "DLC вимкнено в цьому забігу");
            }
            catch (Exception) { }
            return null;
        }

        // ---------- телепортер (основной портал, вызывающий босса) ----------
        Transform tpCache;

        Transform FindTeleporterNow()
        {
            var t = TeleporterInteraction.instance;
            if (t != null) return t.transform;
            var f = UnityEngine.Object.FindObjectOfType<TeleporterInteraction>();
            return f != null ? f.transform : null;
        }

        // для интерфейса: обновляется вместе со сканером, чтобы не искать объект на каждом кадре
        Transform FindTeleporter() { return tpCache; }

        void TeleportToTeleporter()
        {
            var tp = FindTeleporterNow();
            var b = Body;
            if (tp == null || b == null)
            {
                Say(T("No teleporter on this stage", "На этой локации нет телепортера", "На цій локації немає телепорта"));
                return;
            }
            Vector3 dir = b.corePosition - tp.position;
            dir.y = 0f;
            if (dir.sqrMagnitude < 0.01f) dir = Vector3.forward;
            dir.Normalize();
            TeleportMe(tp.position + dir * 5f + Vector3.up * 2f, T("teleporter", "телепортер", "телепорт"));
        }

        // ---------- кик игрока ----------
        float kickArmedUntil;
        int kickArmedId;

        void KickPlayer(PlayerCharacterMasterController p)
        {
            try
            {
                var nu = p.networkUser;
                var conn = nu != null ? nu.connectionToClient : null;
                if (conn == null)
                {
                    Say(T("Cannot kick this player", "Не удалось кикнуть игрока", "Не вдалося кікнути гравця"));
                    return;
                }
                RoR2.Networking.NetworkManagerSystem.singleton.ServerKickClient(conn, new RoR2.Networking.NetworkManagerSystem.SimpleLocalizedKickReason("KICK_REASON_KICK"));
                Say(T("Kicked: ", "Кикнут: ", "Кікнуто: ") + PlayerName(p));
            }
            catch (Exception ex)
            {
                Logger.LogWarning("kick: " + ex.Message);
                Say(T("Cannot kick this player", "Не удалось кикнуть игрока", "Не вдалося кікнути гравця"));
            }
        }

        // ---------- блокировка ввода игры, пока курсор над меню ----------
        readonly List<Rewired.ControllerMap> blockedMaps = new List<Rewired.ControllerMap>();
        bool inputBlocked;

        bool MouseOverMenu()
        {
            if (!open) return false;
            float sc = cfgScale.Value;
            var r = new Rect(win.x * sc, win.y * sc, win.width * sc, win.height * sc);
            var mp = new Vector2(Input.mousePosition.x, Screen.height - Input.mousePosition.y);
            return r.Contains(mp);
        }

        void UpdateInputBlock()
        {
            bool want = open && (MouseOverMenu() || bwAction >= 0 || pend != null);
            if (want == inputBlocked) return;
            SetInputBlocked(want);
        }

        void SetInputBlocked(bool on)
        {
            try
            {
                var lu = LocalUserManager.GetFirstLocalUser();
                var player = lu != null ? lu.inputPlayer : null;
                if (on && player != null)
                {
                    blockedMaps.Clear();
                    foreach (Rewired.ControllerMap m in player.controllers.maps.GetAllMaps())
                    {
                        if (m.enabled) { m.enabled = false; blockedMaps.Add(m); }
                    }
                    inputBlocked = true;
                }
                else
                {
                    foreach (var m in blockedMaps) m.enabled = true;
                    blockedMaps.Clear();
                    inputBlocked = false;
                }
            }
            catch (Exception ex)
            {
                Logger.LogWarning("input block: " + ex.Message);
                blockedMaps.Clear();
                inputBlocked = false;
            }
        }

        // ---------- аимбот ----------
        bool aimbot, aimVisible = true;
        float aimFov = 25f, aimRange = 120f, aimSmooth = 0.3f;
        MethodInfo aimSetter;

        static bool IsHostile(CharacterBody me, CharacterBody b)
        {
            if (b == null || b == me || b.teamComponent == null || me.teamComponent == null) return false;
            var t = b.teamComponent.teamIndex;
            if (t == TeamIndex.Neutral || t == TeamIndex.None || t == me.teamComponent.teamIndex) return false;
            return true;
        }

        static Vector3 AimPointOf(CharacterBody b)
        {
            if (b.mainHurtBox != null && b.mainHurtBox.collider != null) return b.mainHurtBox.collider.bounds.center;
            return b.corePosition;
        }

        void AimbotTick(CharacterBody me)
        {
            if (!aimbot || MouseOverMenu()) return;
            var list = CameraRigController.readOnlyInstancesList;
            if (list.Count == 0) return;
            var crc = list[0];
            if (crc == null || crc.sceneCam == null || !crc.isControlAllowed) return;

            Vector3 origin = crc.sceneCam.transform.position;
            Vector3 fwd = crc.sceneCam.transform.forward;
            CharacterBody best = null;
            float bestAngle = aimFov;
            Vector3 bestPoint = Vector3.zero;
            foreach (var b in CharacterBody.readOnlyInstancesList)
            {
                if (!IsHostile(me, b) || b.healthComponent == null || !b.healthComponent.alive) continue;
                Vector3 tp = AimPointOf(b);
                Vector3 dir = tp - origin;
                if (dir.magnitude > aimRange) continue;
                float ang = Vector3.Angle(fwd, dir);
                if (ang > bestAngle) continue;
                if (aimVisible && Physics.Linecast(origin, tp, LayerIndex.world.mask)) continue;
                best = b; bestAngle = ang; bestPoint = tp;
            }
            if (best == null) return;

            Vector3 want = Vector3.Slerp(fwd, (bestPoint - origin).normalized, 1f - Mathf.Clamp(aimSmooth, 0f, 0.95f));
            SetAimDirection(crc, want);
        }

        void SetAimDirection(CameraRigController crc, Vector3 dir)
        {
            try
            {
                var mode = crc.cameraMode;
                if (mode == null) return;
                object data = mode.DebugGetInstanceData(crc);
                if (data == null) return;
                if (aimSetter == null || aimSetter.DeclaringType != data.GetType())
                    aimSetter = data.GetType().GetMethod("SetPitchYawFromLookVector", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                if (aimSetter != null) aimSetter.Invoke(data, new object[] { dir });
            }
            catch (Exception) { }
        }

        // ---------- ESP: враги и игроки ----------
        bool espEnemies, espPlayers, snapEnemies, snapPlayers, snapItems;

        static readonly Color colEnemy = new Color(1f, 0.3f, 0.3f);
        static readonly Color colBoss = new Color(1f, 0.75f, 0.2f);
        static readonly Color colPlayer = new Color(0.3f, 1f, 0.45f);
        static readonly Color colAlly = new Color(0.35f, 0.85f, 1f);

        void DrawLine(Vector2 a, Vector2 b, Color c, float w)
        {
            if (Event.current.type != EventType.Repaint) return;
            var m = GUI.matrix;
            var oc = GUI.color;
            GUI.color = c;
            float ang = Mathf.Atan2(b.y - a.y, b.x - a.x) * Mathf.Rad2Deg;
            float len = (b - a).magnitude;
            GUIUtility.RotateAroundPivot(ang, a);
            GUI.DrawTexture(new Rect(a.x, a.y - w / 2f, len, w), Texture2D.whiteTexture);
            GUI.matrix = m;
            GUI.color = oc;
        }

        void DrawBoxOutline(Rect r, Color c)
        {
            var oc = GUI.color;
            GUI.color = c;
            GUI.DrawTexture(new Rect(r.x, r.y, r.width, 1.5f), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(r.x, r.yMax - 1.5f, r.width, 1.5f), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(r.x, r.y, 1.5f, r.height), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(r.xMax - 1.5f, r.y, 1.5f, r.height), Texture2D.whiteTexture);
            GUI.color = oc;
        }

        bool ScreenBounds(Camera cam, CharacterBody b, out Rect rect)
        {
            rect = new Rect();
            Bounds bb = new Bounds(b.corePosition, Vector3.one * Mathf.Max(b.radius, 0.5f) * 2f);
            bool has = false;
            if (b.hurtBoxGroup != null && b.hurtBoxGroup.hurtBoxes != null)
            {
                foreach (var hb in b.hurtBoxGroup.hurtBoxes)
                {
                    if (hb == null || hb.collider == null) continue;
                    if (!has) { bb = hb.collider.bounds; has = true; }
                    else bb.Encapsulate(hb.collider.bounds);
                }
            }
            float minX = float.MaxValue, minY = float.MaxValue, maxX = float.MinValue, maxY = float.MinValue;
            for (int i = 0; i < 8; i++)
            {
                Vector3 c = bb.center + Vector3.Scale(bb.extents, new Vector3((i & 1) == 0 ? -1 : 1, (i & 2) == 0 ? -1 : 1, (i & 4) == 0 ? -1 : 1));
                Vector3 sp = cam.WorldToScreenPoint(c);
                if (sp.z <= 0f) return false;
                float y = Screen.height - sp.y;
                minX = Mathf.Min(minX, sp.x); maxX = Mathf.Max(maxX, sp.x);
                minY = Mathf.Min(minY, y); maxY = Mathf.Max(maxY, y);
            }
            rect = new Rect(minX, minY, maxX - minX, maxY - minY);
            return true;
        }

        void DrawEntityEsp()
        {
            var cam = GetCam();
            if (cam == null) return;
            var me = Body;
            Vector3 mePos = me != null ? me.corePosition : cam.transform.position;
            Vector2 origin = new Vector2(Screen.width / 2f, Screen.height);
            int drawn = 0;
            foreach (var b in CharacterBody.readOnlyInstancesList)
            {
                if (b == null || b == me || b.healthComponent == null || !b.healthComponent.alive || b.teamComponent == null) continue;
                bool player = b.isPlayerControlled;
                bool ally = !player && b.teamComponent.teamIndex == TeamIndex.Player;
                var team = b.teamComponent.teamIndex;
                bool enemy = !player && !ally && team != TeamIndex.Neutral && team != TeamIndex.None;
                if ((player || ally) ? !espPlayers : !(enemy && espEnemies)) continue;
                float dist = Vector3.Distance(mePos, b.corePosition);
                if (dist > espRange) continue;

                Rect r;
                if (!ScreenBounds(cam, b, out r)) continue;
                if (r.xMax < 0 || r.x > Screen.width || r.yMax < 0 || r.y > Screen.height) continue;

                Color col = player ? colPlayer : (ally ? colAlly : ((b.isChampion || b.isBoss) ? colBoss : colEnemy));
                bool snap = (player || ally) ? snapPlayers : snapEnemies;
                if (snap) DrawLine(origin, new Vector2(r.center.x, r.yMax), col, 1.5f);

                if (Event.current.type == EventType.Repaint)
                {
                    DrawBoxOutline(r, col);
                    var hc = b.healthComponent;
                    float frac = Mathf.Clamp01(hc.health / Mathf.Max(hc.fullHealth, 1f));
                    var oc = GUI.color;
                    GUI.color = new Color(0, 0, 0, 0.6f);
                    GUI.DrawTexture(new Rect(r.x - 6, r.y, 3, r.height), Texture2D.whiteTexture);
                    GUI.color = Color.Lerp(Color.red, Color.green, frac);
                    GUI.DrawTexture(new Rect(r.x - 6, r.yMax - r.height * frac, 3, r.height * frac), Texture2D.whiteTexture);
                    GUI.color = oc;

                    string name = b.GetDisplayName();
                    if (player) { var m = b.master != null ? b.master.playerCharacterMasterController : null; if (m != null) name = PlayerName(m) + " (" + name + ")"; }
                    var occ = GUI.contentColor;
                    GUI.contentColor = col;
                    var label = new Rect(r.center.x - 120, r.y - 20, 240, 18);
                    var st = sEsp;
                    var oal = st.alignment;
                    st.alignment = TextAnchor.UpperCenter;
                    GUI.Label(label, name + "  " + dist.ToString("0") + "m", st);
                    st.alignment = oal;
                    GUI.contentColor = occ;
                }
                if (++drawn >= 100) break;
            }
        }

        // ---------- глобальный поиск по функциям ----------
        class Feat
        {
            public string name, en;
            public int tab = -1;
            public Action act;
            public Func<bool> on;
        }

        List<Feat> BuildFeatures()
        {
            var l = new List<Feat>();
            string[] tn = TabNames();
            string[] ten = { "Player", "Players", "Items", "Equipment", "Character", "Teleport", "Drones", "Spawn", "Stats", "Scanner", "World", "Music", "Settings" };
            for (int i = 0; i < tn.Length; i++)
            {
                int idx = i;
                l.Add(new Feat { name = T("Open tab: ", "Открыть вкладку: ", "Відкрити вкладку: ") + tn[i], en = "tab " + ten[i], tab = idx });
            }
            Action<string, string, string, string, Func<bool>, Action> add = delegate(string en, string ru, string uk, string tabHint, Func<bool> on, Action act)
            {
                l.Add(new Feat { name = T(en, ru, uk), en = en + " " + tabHint, act = act, on = on });
            };
            add("God mode", "Бессмертие", "Безсмертя", "player", delegate { return god; }, delegate { god = !god; });
            add("Fly", "Полёт", "Політ", "player", delegate { return fly; }, delegate { fly = !fly; });
            add("Noclip", "Ноуклип", "Ноуклип", "player", delegate { return noclip; }, delegate { noclip = !noclip; });
            add("Infinite jumps", "Бесконечные прыжки", "Нескінченні стрибки", "player", delegate { return infJumps; }, delegate { infJumps = !infJumps; });
            add("No skill cooldowns", "Без перезарядки умений", "Без перезарядки вмінь", "player", delegate { return AllSkillsNoCd; }, delegate { AllSkillsNoCd = !AllSkillsNoCd; });
            add("Free purchases", "Бесплатные покупки", "Безкоштовні покупки", "player", delegate { return freeInteract; }, delegate { freeInteract = !freeInteract; });
            add("Aimbot", "Аимбот", "Аімбот", "player aim", delegate { return aimbot; }, delegate { aimbot = !aimbot; });
            add("Full heal", "Полное лечение", "Повне лікування", "player", null, HealFull);
            add("Clear inventory", "Очистить инвентарь", "Очистити інвентар", "player items", null, delegate { var b = Body; if (b != null) ClearInventory(b.inventory); });
            add("X-ray", "Рентген", "Рентген", "scanner esp", delegate { return espOn; }, delegate { espOn = !espOn; });
            add("Enemy ESP", "ESP врагов", "ESP ворогів", "scanner wallhack monsters", delegate { return espEnemies; }, delegate { espEnemies = !espEnemies; });
            add("Player ESP", "ESP игроков", "ESP гравців", "scanner wallhack players", delegate { return espPlayers; }, delegate { espPlayers = !espPlayers; });
            add("Charge teleporter instantly", "Мгновенно зарядить телепортер", "Миттєво зарядити телепорт", "world", null, ChargeTeleporter);
            add("Open all chests", "Открыть все сундуки", "Відкрити всі скрині", "world", null, OpenAllChests);
            add("Kill all enemies", "Убить всех врагов", "Вбити всіх ворогів", "world", null, delegate { KillAllEnemies(false); });
            add("Kill bosses only", "Убить только боссов", "Вбити лише босів", "world", null, delegate { KillAllEnemies(true); });
            add("Next stage", "Следующая локация", "Наступна локація", "world", null, NextStage);
            add("To teleporter", "К телепортеру", "До телепорта", "teleport portal boss", null, TeleportToTeleporter);
            add("Hide HUD", "Скрыть HUD", "Сховати HUD", "settings screenshot", delegate { return hideGameHud; }, delegate { hideGameHud = !hideGameHud; });
            add("FPS counter", "Счётчик FPS", "Лічильник FPS", "settings", delegate { return cfgFps.Value; }, delegate { cfgFps.Value = !cfgFps.Value; });
            add("Ping counter", "Счётчик пинга", "Лічильник пінгу", "settings", delegate { return cfgPing.Value; }, delegate { cfgPing.Value = !cfgPing.Value; });
            add("Reset to default", "Сбросить на стандартную", "Скинути на стандартну", "music", null, ResetMusic);
            foreach (var b in binds)
            {
                var bb = b;
                l.Add(new Feat { name = T("Hotkey: ", "Клавиша: ", "Клавіша: ") + BindName(b), en = "hotkey " + b.en, tab = TSet });
            }
            return l;
        }

        string globalSearch = "";

        List<Entry> BuildSearchResults(string q)
        {
            q = q.Trim().ToLowerInvariant();
            var res = new List<Entry>();
            if (q.Length == 0) return res;
            string[] cat =
            {
                T("Functions", "Функции", "Функції"), T("Items", "Предметы", "Предмети"), T("Equipment", "Снаряжение", "Спорядження"),
                T("Characters", "Персонажи", "Персонажі"), T("Drones", "Дроны", "Дрони"), T("Enemies", "Враги", "Вороги"),
                T("Stages", "Локации", "Локації"), T("Music", "Музыка", "Музика")
            };
            Action<int, List<Entry>> addList = delegate(int c, List<Entry> src)
            {
                if (src == null) return;
                var m = src.Where(e => e.search.IndexOf(q, StringComparison.Ordinal) >= 0).Take(25).ToList();
                if (m.Count == 0) return;
                var h = new Entry(); h.header = true; h.name = cat[c]; h.color = Color.white; res.Add(h);
                foreach (var s in m)
                {
                    // копия, чтобы не менять группы (редкость и т.п.) в общем каталоге
                    var e = new Entry();
                    e.name = s.name; e.color = s.color; e.tex = s.tex; e.uv = s.uv; e.data = s.data; e.prefab = s.prefab;
                    e.search = s.search; e.sub = cat[c]; e.extra = s.extra; e.lockWhy = s.lockWhy; e.group = c;
                    res.Add(e);
                }
            };

            var feats = BuildFeatures().Where(f => (f.name + " " + f.en).ToLowerInvariant().IndexOf(q, StringComparison.Ordinal) >= 0).Take(25).ToList();
            if (feats.Count > 0)
            {
                var h = new Entry(); h.header = true; h.name = cat[0]; h.color = Color.white; res.Add(h);
                foreach (var f in feats)
                {
                    var e = new Entry();
                    e.name = f.name; e.data = f; e.group = 0; e.color = Color.white;
                    e.sub = f.on != null ? (f.on() ? "ON" : "OFF") : "";
                    res.Add(e);
                }
            }
            addList(1, items); addList(2, equips); addList(3, survivors); addList(4, drones);
            addList(5, enemies); addList(6, scenes); addList(7, tracks);
            return res;
        }
    }
}
