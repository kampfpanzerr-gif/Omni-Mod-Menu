using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using RoR2;

namespace RoR2ModMenu
{
    public partial class ModMenu
    {
        // Порядок важен: английский, украинский, русский идут первыми, дальше языки самой игры.
        static readonly string[] LangCodes = { "en", "uk", "ru", "de", "es", "fr", "it", "pt", "tr", "ja", "ko", "zh" };
        static readonly string[] LangNames =
        {
            "English", "Українська", "Русский", "Deutsch", "Español", "Français",
            "Italiano", "Português (BR)", "Türkçe", "日本語", "한국어", "简体中文"
        };

        int lang; // индекс в LangCodes
        readonly Dictionary<string, string>[] packs = new Dictionary<string, string>[LangCodes.Length];

        // Ключ перевода - английский текст. Английский, русский и украинский заданы прямо в коде,
        // остальные языки читаются из lang/<код>.json рядом с плагином (можно добавлять свои).
        string T(string en, string ru, string uk)
        {
            switch (lang)
            {
                case 0: return en;
                case 1: return uk;
                case 2: return ru;
            }
            var pack = GetPack(lang);
            string v;
            if (pack != null && pack.TryGetValue(en, out v) && !string.IsNullOrEmpty(v)) return v;
            return en;
        }

        Dictionary<string, string> GetPack(int i)
        {
            if (packs[i] != null) return packs[i];
            packs[i] = new Dictionary<string, string>();
            try
            {
                string dir = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(Info.Location), "lang");
                string file = System.IO.Path.Combine(dir, LangCodes[i] + ".json");
                if (File.Exists(file))
                {
                    packs[i] = ParseFlatJson(File.ReadAllText(file, Encoding.UTF8));
                }
                else Logger.LogWarning("Language pack not found: " + file);
            }
            catch (Exception ex)
            {
                Logger.LogWarning("Language pack " + LangCodes[i] + ": " + ex.Message);
            }
            return packs[i];
        }

        // Минимальный разбор плоского JSON-объекта {"ключ": "значение" | число}. Своя реализация, чтобы плагин
        // не зависел от внешних библиотек (Newtonsoft.Json есть не у всех установок BepInEx).
        static string JsonString(string s, ref int i)
        {
            var sb = new StringBuilder();
            i++; // открывающая кавычка
            while (i < s.Length)
            {
                char c = s[i++];
                if (c == '"') break;
                if (c == '\\' && i < s.Length)
                {
                    char e = s[i++];
                    switch (e)
                    {
                        case 'n': sb.Append('\n'); break;
                        case 't': sb.Append('\t'); break;
                        case 'r': sb.Append('\r'); break;
                        case 'b': sb.Append('\b'); break;
                        case 'f': sb.Append('\f'); break;
                        case 'u':
                            if (i + 4 <= s.Length) { sb.Append((char)Convert.ToInt32(s.Substring(i, 4), 16)); i += 4; }
                            break;
                        default: sb.Append(e); break;
                    }
                }
                else sb.Append(c);
            }
            return sb.ToString();
        }

        static Dictionary<string, string> ParseFlatJson(string s)
        {
            var d = new Dictionary<string, string>(StringComparer.Ordinal);
            int i = 0;
            while (i < s.Length)
            {
                while (i < s.Length && s[i] != '"') i++;
                if (i >= s.Length) break;
                string key = JsonString(s, ref i);
                while (i < s.Length && s[i] != ':') i++;
                i++;
                while (i < s.Length && char.IsWhiteSpace(s[i])) i++;
                if (i >= s.Length) break;
                string val;
                if (s[i] == '"') val = JsonString(s, ref i);
                else
                {
                    int st = i;
                    while (i < s.Length && s[i] != ',' && s[i] != '}') i++;
                    val = s.Substring(st, i - st).Trim();
                }
                d[key] = val;
            }
            return d;
        }

        static int MapGameLanguage(string name)
        {
            if (string.IsNullOrEmpty(name)) return 0;
            string n = name.ToLowerInvariant();
            if (n.StartsWith("ru")) return 2;
            if (n.StartsWith("uk")) return 1;
            if (n.StartsWith("de")) return 3;
            if (n.StartsWith("es")) return 4;
            if (n.StartsWith("fr")) return 5;
            if (n.StartsWith("it")) return 6;
            if (n.StartsWith("pt")) return 7;
            if (n.StartsWith("tr")) return 8;
            if (n.StartsWith("ja")) return 9;
            if (n.StartsWith("ko")) return 10;
            if (n.StartsWith("zh")) return 11;
            return 0;
        }

        // "auto": язык меню = язык игры, пока игрок сам не выбрал язык в настройках; выбор запоминается в конфиге.
        void UpdateLanguage()
        {
            string v = cfgLang.Value;
            if (v == "auto")
            {
                string gn = "";
                try { gn = RoR2.Language.currentLanguageName; } catch (Exception) { }
                lang = MapGameLanguage(gn);
                return;
            }
            int i = Array.IndexOf(LangCodes, v);
            lang = i >= 0 ? i : 0;
        }

        void SetLanguage(int i)
        {
            lang = i;
            cfgLang.Value = LangCodes[i];
        }
    }
}
